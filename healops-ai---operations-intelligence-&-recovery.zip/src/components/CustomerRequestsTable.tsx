import React from 'react';
import { Check, AlertTriangle } from 'lucide-react';
import { CustomerRequest } from '../types';

interface CustomerRequestsTableProps {
  requests: CustomerRequest[];
  onSelectRequest: (request: CustomerRequest) => void;
}

export const CustomerRequestsTable: React.FC<CustomerRequestsTableProps> = ({
  requests,
  onSelectRequest,
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
      {/* Header */}
      <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-900 tracking-tight">Recent Customer Requests</h3>
          <p className="text-[11px] text-slate-400">
            Click any request to inspect payload suitability and recovery path
          </p>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-600">
          <thead className="bg-[#FAFBFD] text-slate-500 font-medium border-b border-slate-100 text-[11px]">
            <tr>
              <th className="py-2.5 px-4 font-semibold w-10">#</th>
              <th className="py-2.5 px-4 font-semibold">Customer Message</th>
              <th className="py-2.5 px-4 font-semibold">Category</th>
              <th className="py-2.5 px-4 font-semibold">Order / Refund ID</th>
              <th className="py-2.5 px-4 font-semibold">Status</th>
              <th className="py-2.5 px-4 font-semibold text-right">API Data Suitability</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-normal">
            {requests.map((item) => {
              const suitability = item.apiSuitability;
              return (
                <tr
                  key={item.id}
                  onClick={() => onSelectRequest(item)}
                  className="hover:bg-teal-50/30 transition-colors cursor-pointer group"
                >
                  <td className="py-3 px-4 text-slate-400 font-mono text-[11px] tabular-nums">
                    {item.id}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-900 group-hover:text-teal-700 transition-colors">
                    {item.message}
                  </td>
                  <td className="py-3 px-4 text-slate-600">{item.category}</td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-700">
                    {item.refId}
                  </td>
                  <td className="py-3 px-4">
                    {item.status === 'Resolved' && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                        <Check className="w-3 h-3 stroke-[2.5]" />
                        <span>Resolved</span>
                      </span>
                    )}
                    {item.status === 'In Progress' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-blue-50 text-blue-700 border border-blue-200/60">
                        <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
                        <span>In Progress</span>
                      </span>
                    )}
                    {item.status === 'Open' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200/60">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-600"></span>
                        <span>Open</span>
                      </span>
                    )}
                  </td>

                  {/* Clean API Data Suitability Detection (Support Tickets completely removed) */}
                  <td className="py-3 px-4 text-right">
                    {suitability?.status === 'Unsuitable' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-red-50 text-red-700 border border-red-200">
                        <AlertTriangle className="w-3 h-3 text-red-600" />
                        <span>Unsuitable: {suitability.anomalyType}</span>
                      </span>
                    )}

                    {suitability?.status === 'Corrected' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        <Check className="w-3 h-3 text-emerald-600 stroke-[2.5]" />
                        <span>Auto-Corrected</span>
                      </span>
                    )}

                    {suitability?.status === 'Suitable' && (
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-medium text-slate-500">
                        <Check className="w-3 h-3 text-slate-400" />
                        <span>Compliant</span>
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
