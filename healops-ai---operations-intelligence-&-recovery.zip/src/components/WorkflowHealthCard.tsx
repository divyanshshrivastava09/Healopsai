import React from 'react';
import { WorkflowItem } from '../types';

interface WorkflowHealthCardProps {
  workflows: WorkflowItem[];
  onSelectWorkflow: (wf: WorkflowItem) => void;
}

export const WorkflowHealthCard: React.FC<WorkflowHealthCardProps> = ({
  workflows,
  onSelectWorkflow,
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden flex flex-col h-full">
      {/* Header */}
      <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-900 tracking-tight">Workflow Health</h3>
          <p className="text-[11px] text-slate-400">Microservice execution & error rates</p>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-left text-xs text-slate-600">
          <thead className="bg-[#FAFBFD] text-slate-500 font-medium border-b border-slate-100 text-[11px]">
            <tr>
              <th className="py-2.5 px-4 font-semibold">Workflow</th>
              <th className="py-2.5 px-3 font-semibold">Health</th>
              <th className="py-2.5 px-3 font-semibold">Last Execution</th>
              <th className="py-2.5 px-3 font-semibold text-center">Failures</th>
              <th className="py-2.5 px-4 font-semibold text-right">Recovery Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {workflows.map((wf) => (
              <tr
                key={wf.id}
                onClick={() => onSelectWorkflow(wf)}
                className="hover:bg-teal-50/30 transition-colors cursor-pointer group"
              >
                <td className="py-3 px-4 font-medium text-slate-900 group-hover:text-teal-700 transition-colors">
                  {wf.name}
                </td>
                <td className="py-3 px-3">
                  {wf.health === 'Healthy' && (
                    <span className="inline-flex items-center gap-1.5 text-xs text-emerald-700 font-medium">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span>Healthy</span>
                    </span>
                  )}
                  {wf.health === 'Degraded' && (
                    <span className="inline-flex items-center gap-1.5 text-xs text-amber-700 font-medium">
                      <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                      <span>Degraded</span>
                    </span>
                  )}
                  {wf.health === 'Failed' && (
                    <span className="inline-flex items-center gap-1.5 text-xs text-red-700 font-medium">
                      <span className="w-2 h-2 rounded-full bg-red-500"></span>
                      <span>Failed</span>
                    </span>
                  )}
                </td>
                <td className="py-3 px-3 text-slate-400">{wf.lastExecution}</td>
                <td className="py-3 px-3 text-center font-mono tabular-nums text-slate-700">
                  {wf.recentFailures}
                </td>
                <td className="py-3 px-4 text-right">
                  {wf.recoveryStatus === '+ In Progress' && (
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-blue-50 text-blue-700 border border-blue-200/50">
                      In Progress
                    </span>
                  )}
                  {wf.recoveryStatus === '+ Recovered' && (
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-teal-50 text-teal-700 border border-teal-200/50">
                      Recovered
                    </span>
                  )}
                  {wf.recoveryStatus === 'Needs Attention' && (
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-amber-50 text-amber-700 border border-amber-200/50">
                      Needs Attention
                    </span>
                  )}
                  {wf.recoveryStatus === '—' && (
                    <span className="text-slate-300">—</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
