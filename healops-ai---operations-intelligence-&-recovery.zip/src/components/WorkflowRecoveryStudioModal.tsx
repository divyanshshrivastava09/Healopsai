import React, { useState } from 'react';
import {
  X,
  Activity,
  AlertCircle,
  CheckCircle2,
  Cpu,
  ArrowRight,
  ShieldCheck,
  RotateCcw,
  UserCheck,
  FileText,
  Code2,
  Check,
  Lock,
  Sparkles,
  Zap
} from 'lucide-react';
import { WorkflowInvestigation } from '../types';

interface WorkflowRecoveryStudioModalProps {
  investigation: WorkflowInvestigation | null;
  onClose: () => void;
  onApproveAndRetry: (workflowId: string) => void;
}

export const WorkflowRecoveryStudioModal: React.FC<WorkflowRecoveryStudioModalProps> = ({
  investigation,
  onClose,
  onApproveAndRetry,
}) => {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [isRetrying, setIsRetrying] = useState<boolean>(false);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);
  const [humanApproved, setHumanApproved] = useState<boolean>(false);

  if (!investigation) return null;

  const handleExecuteRetry = () => {
    setIsRetrying(true);
    setTimeout(() => {
      setIsRetrying(false);
      setIsCompleted(true);
      onApproveAndRetry(investigation.workflowId);
    }, 1200);
  };

  const steps = [
    { num: 1, title: 'Monitor & Error Detection' },
    { num: 2, title: 'Analyze Logs & Likely Cause' },
    { num: 3, title: 'Recommend Corrective Action' },
    { num: 4, title: 'Validate, Approval & Retry' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-3xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-teal-300">
                  {investigation.incidentId}
                </span>
                <span className="text-sm font-bold tracking-tight">
                  {investigation.workflowName}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Autonomous workflow detection, diagnosis, and verified recovery
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 4-Step Stepper Bar */}
        <div className="px-6 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs">
          {steps.map((st) => {
            const isCurrent = activeStep === st.num;
            const isPast = activeStep > st.num || isCompleted;
            return (
              <button
                key={st.num}
                onClick={() => setActiveStep(st.num)}
                className={`flex items-center gap-2 font-medium transition-colors cursor-pointer ${
                  isCurrent
                    ? 'text-teal-700 font-bold'
                    : isPast
                    ? 'text-slate-700'
                    : 'text-slate-400'
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-mono font-bold ${
                    isPast
                      ? 'bg-emerald-500 text-white'
                      : isCurrent
                      ? 'bg-teal-600 text-white shadow-xs'
                      : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  {isPast ? <Check className="w-3 h-3 stroke-[3]" /> : st.num}
                </div>
                <span className="hidden sm:inline text-[11px]">{st.title}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1 text-xs text-slate-700">
          {/* STEP 1: MONITOR & DETECT */}
          {activeStep === 1 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  1. Workflow Monitor & Error Anomaly Detection
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-red-50 text-red-700 border border-red-200 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" />
                  <span>Failure Intercepted</span>
                </span>
              </div>

              {/* Error Summary Card */}
              <div className="bg-red-50/50 border border-red-200 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-red-900">
                    {investigation.errorDetails.code}
                  </span>
                  <span className="text-[11px] text-red-700 font-mono">
                    Detected at {investigation.detectedAt}
                  </span>
                </div>
                <p className="text-xs text-red-950 font-medium">
                  {investigation.errorDetails.message}
                </p>
                <div className="pt-2 border-t border-red-200/60 flex items-center gap-4 text-[11px] text-red-800">
                  <span><strong>Component:</strong> {investigation.errorDetails.component}</span>
                  <span>·</span>
                  <span><strong>Impact:</strong> {investigation.errorDetails.impact}</span>
                </div>
              </div>

              {/* Execution Telemetry Snapshot */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-2">
                <div className="text-[11px] font-bold text-slate-600 uppercase">
                  Runtime Observation
                </div>
                <p className="text-xs text-slate-700 leading-relaxed">
                  HealOps sensor telemetry detected an unexpected outcome during workflow stage execution.
                  Upstream requests received HTTP failure responses, exceeding error tolerance thresholds.
                </p>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => setActiveStep(2)}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <span>Proceed to Log Analysis</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: ANALYZE LOGS & LIKELY CAUSE */}
          {activeStep === 2 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  2. Log & Execution Data Analysis
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-blue-50 text-blue-700 border border-blue-200">
                  Confidence: {investigation.logAnalysis.confidence}%
                </span>
              </div>

              {/* Stack Trace Log Box */}
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-slate-600 uppercase">
                  Execution Stack Trace Logs
                </div>
                <div className="p-3 bg-slate-900 text-red-300 font-mono text-[11px] rounded-xl overflow-x-auto border border-slate-800 space-y-1">
                  {investigation.logAnalysis.stackTrace.map((line, i) => (
                    <div key={i}>{line}</div>
                  ))}
                </div>
              </div>

              {/* Identified Likely Cause */}
              <div className="bg-teal-50/60 border border-teal-200 rounded-xl p-4 space-y-2">
                <div className="flex items-center gap-2 text-teal-900 font-bold text-xs uppercase tracking-wide">
                  <Sparkles className="w-4 h-4 text-teal-600" />
                  <span>Identified Likely Cause</span>
                </div>
                <p className="text-xs text-slate-800 font-medium leading-relaxed">
                  {investigation.logAnalysis.likelyCause}
                </p>
                <div className="text-[11px] text-teal-800 pt-1 font-mono">
                  <strong>Supporting Evidence:</strong> {investigation.logAnalysis.evidence}
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => setActiveStep(1)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Back
                </button>
                <button
                  onClick={() => setActiveStep(3)}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <span>Review Recommended Action</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: RECOMMEND / GENERATE CORRECTIVE ACTION */}
          {activeStep === 3 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  3. Recommend & Generate Corrective Action
                </span>
                <span
                  className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold border ${
                    investigation.correctiveAction.riskLevel === 'Low'
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : 'bg-amber-50 text-amber-700 border-amber-200'
                  }`}
                >
                  Risk: {investigation.correctiveAction.riskLevel} (
                  {investigation.correctiveAction.requiresHumanApproval
                    ? 'Requires Human Approval'
                    : 'Safe for Auto-Apply'}
                  )
                </span>
              </div>

              {/* Recommendation Card */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                <h4 className="text-xs font-bold text-slate-900">
                  {investigation.correctiveAction.title}
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {investigation.correctiveAction.description}
                </p>
              </div>

              {/* Code Diff Box */}
              <div className="space-y-1.5">
                <div className="text-[11px] font-bold text-slate-600 uppercase flex items-center gap-1.5">
                  <Code2 className="w-3.5 h-3.5" />
                  <span>Synthesized Corrective Patch Diff</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-[11px]">
                  <div className="p-3 bg-red-50/60 border border-red-200 rounded-xl">
                    <div className="text-[10px] font-bold text-red-700 uppercase mb-1">
                      - Original Execution Logic
                    </div>
                    <pre className="text-red-950 overflow-x-auto whitespace-pre-wrap leading-relaxed">
                      {investigation.correctiveAction.patchDiff.before}
                    </pre>
                  </div>
                  <div className="p-3 bg-emerald-50/60 border border-emerald-200 rounded-xl">
                    <div className="text-[10px] font-bold text-emerald-700 uppercase mb-1">
                      + Proposed Corrective Action
                    </div>
                    <pre className="text-emerald-950 overflow-x-auto whitespace-pre-wrap leading-relaxed">
                      {investigation.correctiveAction.patchDiff.after}
                    </pre>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => setActiveStep(2)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Back
                </button>
                <button
                  onClick={() => setActiveStep(4)}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <span>Proceed to Validation & Retry</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: VALIDATE, HUMAN APPROVAL & RETRY */}
          {activeStep === 4 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  4. Validate Proposed Fix, Approval Gate & Retry
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Validation Passed</span>
                </span>
              </div>

              {/* Validation Checklist */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
                <div className="text-[11px] font-bold text-slate-700 uppercase">
                  Canary Sandbox Assertion Checks
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {investigation.validationResults.checks.map((chk) => (
                    <div
                      key={chk.name}
                      className="p-2.5 bg-white rounded-lg border border-slate-200 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-xs font-medium text-slate-800">{chk.name}</span>
                      </div>
                      <span className="font-mono text-[10px] text-slate-400">{chk.latency}</span>
                    </div>
                  ))}
                </div>
                <div className="text-[11px] text-emerald-800 font-medium pt-1">
                  ✓ {investigation.validationResults.canaryOutcome}
                </div>
              </div>

              {/* HUMAN APPROVAL GATE */}
              {investigation.correctiveAction.requiresHumanApproval && !isCompleted && (
                <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-amber-900 font-bold text-xs uppercase">
                      <UserCheck className="w-4 h-4 text-amber-600" />
                      <span>Human Approval Required (Pending Approval)</span>
                    </div>
                    <span className="text-[10px] font-mono text-amber-800 bg-amber-100 px-2 py-0.5 rounded font-bold">
                      Policy: Financial Ledger Protection
                    </span>
                  </div>
                  <p className="text-xs text-amber-950">
                    This corrective action involves failover routing for enterprise billing settlement.
                    An authorized engineer must explicitly sign off before live execution and traffic retry.
                  </p>
                  <div className="flex items-center justify-between pt-1">
                    <div className="text-[11px] text-slate-600">
                      Authorized Approver: <strong>Riya Sharma</strong> (Product Engineer)
                    </div>
                    <button
                      onClick={() => setHumanApproved(!humanApproved)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
                        humanApproved
                          ? 'bg-emerald-600 text-white'
                          : 'bg-white text-slate-800 border border-amber-300 hover:bg-amber-100'
                      }`}
                    >
                      {humanApproved ? (
                        <>
                          <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                          <span>Signed Off by Riya Sharma</span>
                        </>
                      ) : (
                        <span>Sign Off Approval Gate</span>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* Retry & Verified Outcome */}
              {isCompleted ? (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2 text-xs animate-in fade-in duration-200">
                  <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Failed Process Retried Successfully · Recovery Verified!</span>
                  </div>
                  <p className="text-emerald-950">
                    The corrected fix has been applied to live traffic. Downstream dependencies responded with 200 OK.
                    Incident marked resolved and workflow restored to Healthy.
                  </p>
                  <div className="p-2.5 bg-slate-900 text-emerald-300 font-mono text-[11px] rounded-lg overflow-x-auto">
                    {JSON.stringify(investigation.retryState.outputData, null, 2)}
                  </div>
                </div>
              ) : null}

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => setActiveStep(3)}
                  className="px-4 py-2 text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Back
                </button>

                {!isCompleted ? (
                  <button
                    onClick={handleExecuteRetry}
                    disabled={
                      isRetrying ||
                      (investigation.correctiveAction.requiresHumanApproval && !humanApproved)
                    }
                    className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-lg flex items-center gap-2 shadow-xs transition-all cursor-pointer"
                  >
                    {isRetrying ? (
                      <>
                        <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                        <span>Applying Fix & Retrying Process...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-3.5 h-3.5 fill-current" />
                        <span>
                          {investigation.correctiveAction.requiresHumanApproval
                            ? humanApproved
                              ? 'Execute Retry With Approval'
                              : 'Awaiting Human Approval'
                            : 'Validate & Retry Failed Process'}
                        </span>
                      </>
                    )}
                  </button>
                ) : (
                  <button
                    onClick={onClose}
                    className="px-5 py-2.5 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
                  >
                    Close Studio
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
