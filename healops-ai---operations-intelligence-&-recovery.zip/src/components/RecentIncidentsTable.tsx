import React from 'react';
import { IncidentItem } from '../types';

interface RecentIncidentsTableProps {
  incidents: IncidentItem[];
  onSelectIncident: (incident: IncidentItem) => void;
}

export const RecentIncidentsTable: React.FC<RecentIncidentsTableProps> = ({
  incidents,
  onSelectIncident,
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
      {/* Header */}
      <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-900 tracking-tight">Recent Incidents</h3>
          <p className="text-[11px] text-slate-400">Click any incident to inspect root cause & schema patch</p>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs text-slate-600">
          <thead className="bg-[#FAFBFD] text-slate-500 font-medium border-b border-slate-100 text-[11px]">
            <tr>
              <th className="py-2.5 px-4 font-semibold">ID</th>
              <th className="py-2.5 px-4 font-semibold">Workflow</th>
              <th className="py-2.5 px-4 font-semibold">Failure Type</th>
              <th className="py-2.5 px-4 font-semibold">Severity</th>
              <th className="py-2.5 px-4 font-semibold">Detected At</th>
              <th className="py-2.5 px-4 font-semibold text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {incidents.map((inc) => (
              <tr
                key={inc.id}
                onClick={() => onSelectIncident(inc)}
                className="hover:bg-teal-50/30 transition-colors cursor-pointer group"
              >
                <td className="py-3 px-4 font-mono font-medium text-[11px] text-teal-700 group-hover:underline">
                  {inc.id}
                </td>
                <td className="py-3 px-4 font-medium text-slate-900 group-hover:text-teal-700 transition-colors">
                  {inc.workflow}
                </td>
                <td className="py-3 px-4 text-slate-700">{inc.failureType}</td>
                <td className="py-3 px-4">
                  {inc.severity === 'High' && (
                    <span className="inline-flex items-center gap-1.5 text-xs text-red-600 font-medium">
                      <span className="w-2 h-2 rounded-full bg-red-500"></span>
                      <span>High</span>
                    </span>
                  )}
                  {inc.severity === 'Medium' && (
                    <span className="inline-flex items-center gap-1.5 text-xs text-amber-600 font-medium">
                      <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                      <span>Medium</span>
                    </span>
                  )}
                  {inc.severity === 'Low' && (
                    <span className="inline-flex items-center gap-1.5 text-xs text-emerald-600 font-medium">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      <span>Low</span>
                    </span>
                  )}
                </td>
                <td className="py-3 px-4 text-slate-400 font-mono text-[11px] tabular-nums">
                  {inc.detectedAt}
                </td>
                <td className="py-3 px-4 text-right">
                  {inc.status === 'Diagnosed' && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-blue-50 text-blue-700 border border-blue-200/60">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                      <span>Diagnosed</span>
                    </span>
                  )}
                  {inc.status === 'In Progress' && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-blue-50 text-blue-700 border border-blue-200/60">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600 animate-pulse"></span>
                      <span>In Progress</span>
                    </span>
                  )}
                  {inc.status === 'Resolved' && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-600"></span>
                      <span>Resolved</span>
                    </span>
                  )}
                  {inc.status === 'Escalated' && (
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-medium bg-red-50 text-red-700 border border-red-200/60">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-600"></span>
                      <span>Escalated</span>
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
