import React from 'react';
import { Play, AlertCircle, Check, Clock } from 'lucide-react';

interface StatsGridProps {
  stats: {
    totalExecutions: number;
    failedWorkflows: number;
    verifiedRecoveries: number;
    pendingApprovals: number;
  };
  onSelectFailedWorkflows?: () => void;
  onSelectPendingApprovals?: () => void;
}

export const StatsGrid: React.FC<StatsGridProps> = ({
  stats,
  onSelectFailedWorkflows,
  onSelectPendingApprovals,
}) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* 1. Total Workflow Executions */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs transition hover:shadow-sm">
        <div className="flex items-start justify-between">
          <div className="w-9 h-9 rounded-lg bg-teal-50 flex items-center justify-center text-teal-700">
            <Play className="w-4 h-4 fill-current ml-0.5" />
          </div>
        </div>
        <div className="mt-3">
          <div className="text-xs font-medium text-slate-700">Total Workflow Executions</div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight tabular-nums mt-0.5 font-mono">
            {stats.totalExecutions}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Sample data · Not real records</div>
        </div>
        <div className="mt-4 pt-2.5 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1 text-xs font-semibold text-emerald-600">
            <span>↑ 12%</span>
          </div>
          {/* Sparkline curve */}
          <svg className="w-24 h-5 stroke-teal-500 fill-none" viewBox="0 0 100 20">
            <path
              d="M0 16 Q 15 14, 25 18 T 50 10 T 75 8 T 100 3"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>

      {/* 2. Failed Workflows (Clickable to inspect & recover) */}
      <div
        onClick={onSelectFailedWorkflows}
        className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs transition hover:shadow-md hover:border-red-300 cursor-pointer group"
        title="Click to monitor failing workflow & initiate recovery"
      >
        <div className="flex items-start justify-between">
          <div className="w-9 h-9 rounded-lg bg-red-500 flex items-center justify-center text-white shadow-xs shadow-red-500/30 group-hover:scale-105 transition-transform">
            <span className="font-extrabold text-sm font-sans">!</span>
          </div>
          <span className="text-[10px] font-semibold text-red-700 bg-red-50 px-2 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity">
            Diagnose →
          </span>
        </div>
        <div className="mt-3">
          <div className="text-xs font-medium text-slate-700">Failed Workflows</div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight tabular-nums mt-0.5 font-mono">
            {stats.failedWorkflows}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Sample data · Not real records</div>
        </div>
        <div className="mt-4 pt-2.5 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1 text-xs font-semibold text-red-600">
            <span>↑ 3%</span>
          </div>
          {/* Sparkline curve */}
          <svg className="w-24 h-5 stroke-red-500 fill-none" viewBox="0 0 100 20">
            <path
              d="M0 15 Q 20 18, 40 12 T 70 14 T 100 8"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>

      {/* 3. Verified Recoveries */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs transition hover:shadow-sm">
        <div className="flex items-start justify-between">
          <div className="w-9 h-9 rounded-lg bg-emerald-500 flex items-center justify-center text-white shadow-xs shadow-emerald-500/30">
            <Check className="w-4 h-4 stroke-[2.5]" />
          </div>
        </div>
        <div className="mt-3">
          <div className="text-xs font-medium text-slate-700">Verified Recoveries</div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight tabular-nums mt-0.5 font-mono">
            {stats.verifiedRecoveries}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Sample data · Not real records</div>
        </div>
        <div className="mt-4 pt-2.5 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1 text-xs font-semibold text-emerald-600">
            <span>↑ 50%</span>
          </div>
          {/* Sparkline curve */}
          <svg className="w-24 h-5 stroke-emerald-500 fill-none" viewBox="0 0 100 20">
            <path
              d="M0 18 Q 20 15, 45 14 T 70 7 T 100 4"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>

      {/* 4. Pending Approvals (Clickable to review & sign off) */}
      <div
        onClick={onSelectPendingApprovals}
        className="bg-white rounded-xl border border-slate-200/90 p-4 shadow-xs transition hover:shadow-md hover:border-amber-300 cursor-pointer group"
        title="Click to review proposed fix and grant human approval"
      >
        <div className="flex items-start justify-between">
          <div className="w-9 h-9 rounded-lg bg-amber-500 flex items-center justify-center text-white shadow-xs shadow-amber-500/30 group-hover:scale-105 transition-transform">
            <Clock className="w-4 h-4 stroke-[2.5]" />
          </div>
          <span className="text-[10px] font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity">
            Review Gate →
          </span>
        </div>
        <div className="mt-3">
          <div className="text-xs font-medium text-slate-700">Pending Approvals</div>
          <div className="text-2xl font-bold text-slate-900 tracking-tight tabular-nums mt-0.5 font-mono">
            {stats.pendingApprovals}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">Sample data · Not real records</div>
        </div>
        <div className="mt-4 pt-2.5 border-t border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-1 text-xs font-semibold text-amber-600">
            <span>↓ 33%</span>
          </div>
          {/* Sparkline curve */}
          <svg className="w-24 h-5 stroke-amber-500 fill-none" viewBox="0 0 100 20">
            <path
              d="M0 6 Q 25 8, 45 10 T 70 14 T 100 17"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>
    </div>
  );
};
