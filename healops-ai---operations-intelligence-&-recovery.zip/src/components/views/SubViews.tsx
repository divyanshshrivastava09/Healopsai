import React, { useState } from 'react';
import {
  NavigationTab,
  CustomerRequest,
  WorkflowItem,
  IncidentItem,
  ServiceStatus
} from '../../types';
import {
  ArrowLeft,
  Search,
  Package,
  RotateCcw,
  GitMerge,
  ShieldAlert,
  Cpu,
  Activity,
  History,
  Layers,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Filter
} from 'lucide-react';
import { RecoveryCenterView } from './RecoveryCenterView';
import { SystemHealthView } from './SystemHealthView';

interface SubViewsProps {
  tab: NavigationTab;
  onBackToOverview: () => void;
  customerRequests: CustomerRequest[];
  workflows: WorkflowItem[];
  incidents: IncidentItem[];
  services: ServiceStatus[];
  onSelectIncident: (inc: IncidentItem) => void;
  selectedRequestForRecovery: CustomerRequest | null;
  onSelectRequestForRecovery: (req: CustomerRequest) => void;
  onApplyCorrection: (id: number) => void;
  onNavigateTab: (tab: NavigationTab) => void;
}

export const SubViews: React.FC<SubViewsProps> = ({
  tab,
  onBackToOverview,
  customerRequests,
  workflows,
  incidents,
  services,
  onSelectIncident,
  selectedRequestForRecovery,
  onSelectRequestForRecovery,
  onApplyCorrection,
  onNavigateTab,
}) => {
  // 1. RECOVERY CENTER VIEW
  if (tab === 'recovery-center') {
    return (
      <div className="space-y-4">
        <button
          onClick={onBackToOverview}
          className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors inline-flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Overview</span>
        </button>
        <RecoveryCenterView
          customerRequests={customerRequests}
          selectedRequest={selectedRequestForRecovery}
          onSelectRequest={onSelectRequestForRecovery}
          onApplyCorrection={onApplyCorrection}
          onNavigateToHealth={() => onNavigateTab('system-health')}
        />
      </div>
    );
  }

  // 2. SYSTEM HEALTH VIEW
  if (tab === 'system-health') {
    return (
      <div className="space-y-4">
        <button
          onClick={onBackToOverview}
          className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors inline-flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Overview</span>
        </button>
        <SystemHealthView
          customerRequests={customerRequests}
          services={services}
          onNavigateToRecovery={() => onNavigateTab('recovery-center')}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Back button & Title */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToOverview}
            className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 transition-colors flex items-center gap-1.5 text-xs font-semibold cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Overview</span>
          </button>
          <div>
            <h1 className="text-xl font-bold text-slate-900 capitalize">
              {tab.replace('-', ' ')}
            </h1>
            <p className="text-xs text-slate-500">
              HealOps AI autonomous telemetry and operation controls
            </p>
          </div>
        </div>
      </div>

      {/* ORDER TRACKING VIEW */}
      {tab === 'order-tracking' && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs">
            <h2 className="text-sm font-bold text-slate-900 mb-3">Live Order Fulfillment Telemetry</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {customerRequests
                .filter((r) => r.category === 'Order Tracking' || r.refId.startsWith('ORD'))
                .map((req) => (
                  <div key={req.id} className="p-4 rounded-xl border border-slate-100 bg-slate-50/50 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-xs text-teal-700">{req.refId}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-emerald-100 text-emerald-800">
                        {req.status}
                      </span>
                    </div>
                    <div className="text-xs font-medium text-slate-800">{req.message}</div>
                    <div className="text-[11px] text-slate-500">
                      <strong>Resolution:</strong> {req.resolution}
                    </div>
                    <div className="text-[10px] text-slate-400">Timestamp: {req.timestamp || 'Today'}</div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* REFUND SUPPORT VIEW */}
      {tab === 'refund-support' && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900">Refund Processing Pipeline</h2>
            <span className="text-xs font-mono text-teal-700 bg-teal-50 px-2 py-1 rounded border border-teal-200">
              Gateway: Stripe / PayPal Ingest
            </span>
          </div>
          <div className="divide-y divide-slate-100">
            {customerRequests
              .filter((r) => r.category === 'Refund Inquiry' || r.refId.startsWith('REF'))
              .map((r) => (
                <div key={r.id} className="py-3 flex items-center justify-between">
                  <div>
                    <div className="text-xs font-semibold text-slate-900">{r.message}</div>
                    <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                      Ref: {r.refId} · Customer: {r.customerName}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="px-2 py-0.5 rounded text-xs font-medium bg-blue-50 text-blue-700 border border-blue-200">
                      {r.status}
                    </span>
                    <button className="px-3 py-1 bg-teal-600 hover:bg-teal-700 text-white rounded text-xs font-medium cursor-pointer">
                      Approve & Re-queue
                    </button>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* WORKFLOW MONITOR & SYSTEM ARCHITECTURE */}
      {(tab === 'workflow-monitor' || tab === 'system-architecture') && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-xs">
            <h2 className="text-sm font-bold text-slate-900 mb-2">Interconnected Service Topology</h2>
            <p className="text-xs text-slate-500 mb-6">
              Autonomous self-healing mesh connecting ingest gateways, transformer engines, and storage.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {services.map((svc, i) => (
                <div
                  key={svc.name}
                  className="p-4 rounded-xl border border-slate-200 bg-gradient-to-b from-white to-slate-50/70 shadow-2xs relative"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900">{svc.name}</span>
                    <span className="w-2.5 h-2.5 rounded-full bg-teal-500"></span>
                  </div>
                  <div className="mt-3 text-[11px] text-slate-500 space-y-1 font-mono">
                    <div>Status: {svc.status}</div>
                    <div>Latency: {svc.latency}</div>
                    <div>Node ID: mesh-0{i + 1}</div>
                  </div>
                  <div className="mt-3 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[10px] text-teal-700 font-medium">
                    <span>Self-Healing: ACTIVE</span>
                    <span>100% Invariant</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* INCIDENT INTELLIGENCE */}
      {(tab === 'incident-intelligence' || tab === 'recovery-history') && (
        <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs space-y-4">
          <h2 className="text-sm font-bold text-slate-900">Comprehensive Incident Intelligence Ledger</h2>
          <div className="space-y-3">
            {incidents.map((inc) => (
              <div
                key={inc.id}
                onClick={() => onSelectIncident(inc)}
                className="p-4 rounded-xl border border-slate-200 hover:border-teal-300 hover:bg-teal-50/20 transition-all cursor-pointer flex items-start justify-between"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-teal-700">{inc.id}</span>
                    <span className="text-xs font-bold text-slate-900">
                      {inc.workflow} · {inc.failureType}
                    </span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.2 rounded border ${
                        inc.severity === 'High'
                          ? 'bg-red-50 text-red-700 border-red-200'
                          : 'bg-amber-50 text-amber-700 border-amber-200'
                      }`}
                    >
                      {inc.severity}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{inc.rootCause}</p>
                </div>
                <button className="px-3 py-1 bg-slate-100 hover:bg-teal-50 text-slate-700 hover:text-teal-700 rounded text-xs font-medium border border-slate-200">
                  Inspect RCA →
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* DEFAULT FALLBACK VIEW FOR OTHER TABS */}
      {tab !== 'order-tracking' &&
        tab !== 'refund-support' &&
        tab !== 'workflow-monitor' &&
        tab !== 'system-architecture' &&
        tab !== 'incident-intelligence' &&
        tab !== 'recovery-history' && (
          <div className="bg-white rounded-xl border border-slate-200 p-8 shadow-xs text-center space-y-3">
            <div className="w-12 h-12 rounded-full bg-teal-50 text-teal-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-slate-900 capitalize">
              {tab.replace('-', ' ')} Active
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              All sub-systems are streaming live telemetry to the Operations Overview. Switch back anytime to inspect global workflows and real-time recoveries.
            </p>
            <button
              onClick={onBackToOverview}
              className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-lg text-xs font-semibold"
            >
              Return to Operations Overview
            </button>
          </div>
        )}
    </div>
  );
};
