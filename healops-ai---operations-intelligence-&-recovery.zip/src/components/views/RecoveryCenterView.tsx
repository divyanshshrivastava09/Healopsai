import React, { useState } from 'react';
import {
  Cpu,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
  Zap,
  Code2,
  ShieldCheck,
  Activity,
  Layers,
  Sparkles
} from 'lucide-react';
import { CustomerRequest, NavigationTab } from '../../types';

interface RecoveryCenterViewProps {
  customerRequests: CustomerRequest[];
  selectedRequest: CustomerRequest | null;
  onSelectRequest: (req: CustomerRequest) => void;
  onApplyCorrection: (requestId: number) => void;
  onNavigateToHealth: () => void;
}

export const RecoveryCenterView: React.FC<RecoveryCenterViewProps> = ({
  customerRequests,
  selectedRequest,
  onSelectRequest,
  onApplyCorrection,
  onNavigateToHealth,
}) => {
  // Find all requests with suitability data
  const unsuitableOrCorrected = customerRequests.filter(
    (r) => r.apiSuitability.status === 'Unsuitable' || r.apiSuitability.status === 'Corrected'
  );

  const activeReq = selectedRequest || unsuitableOrCorrected[0] || customerRequests[0];
  const [pipelinePhase, setPipelinePhase] = useState<'all' | 'raw' | 'rule' | 'canary' | 'output'>('all');
  const [isExecuting, setIsExecuting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const handleRunCorrection = () => {
    setIsExecuting(true);
    setSuccessMessage(null);
    setTimeout(() => {
      setIsExecuting(false);
      onApplyCorrection(activeReq.id);
      setSuccessMessage(`API payload for ${activeReq.refId} successfully corrected & validated!`);
    }, 900);
  };

  const suitability = activeReq.apiSuitability;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-gradient-to-r from-slate-900 to-[#0A1826] text-white p-6 rounded-2xl border border-slate-800 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-teal-500/20 text-teal-400 border border-teal-500/30">
                <Cpu className="w-4 h-4" />
              </span>
              <h1 className="text-xl font-bold tracking-tight">Recovery Center: API Data Correction Engine</h1>
            </div>
            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              When external webhooks, client SDKs, or legacy microservices transmit unsuitable data schemas,
              HealOps AI synthesizes zero-downtime runtime correction adapters without code deploys.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onNavigateToHealth}
              className="px-4 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-teal-300 rounded-lg border border-teal-500/30 transition-all flex items-center gap-2 cursor-pointer shadow-sm"
            >
              <Activity className="w-3.5 h-3.5 text-teal-400" />
              <span>View System Health Impact →</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Two-Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: List of Detected API Ingestion Payloads (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              Detected Ingestion Anomalies
            </h2>
            <span className="text-[11px] font-mono text-slate-500">
              {unsuitableOrCorrected.length} Payloads Queued
            </span>
          </div>

          <div className="space-y-2">
            {unsuitableOrCorrected.map((req) => {
              const isSelected = req.id === activeReq.id;
              const isCorrected = req.apiSuitability.status === 'Corrected';
              return (
                <div
                  key={req.id}
                  onClick={() => {
                    onSelectRequest(req);
                    setSuccessMessage(null);
                  }}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer text-left ${
                    isSelected
                      ? 'bg-white border-teal-500 shadow-md ring-1 ring-teal-500/30'
                      : 'bg-white/80 border-slate-200 hover:border-slate-300 hover:bg-white'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-slate-900">{req.refId}</span>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                        isCorrected
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-red-50 text-red-700 border-red-200'
                      }`}
                    >
                      {isCorrected ? '✓ Corrected' : '⚠️ Unsuitable'}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-slate-800 mt-1.5">{req.message}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                    <strong>Issue:</strong> {req.apiSuitability.anomalyType}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: Step-by-Step Correction Pipeline (8 cols) */}
        <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          {/* Header for Active Item */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs font-bold text-teal-800 bg-teal-50 px-2 py-0.5 rounded border border-teal-200">
                  {activeReq.refId}
                </span>
                <span className="text-sm font-bold text-slate-900">{activeReq.category}</span>
                <span
                  className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                    suitability.status === 'Corrected'
                      ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                      : 'bg-red-50 text-red-700 border-red-200'
                  }`}
                >
                  {suitability.status}
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-1 font-medium">
                {suitability.detectedIssue}
              </p>
            </div>

            {suitability.status === 'Unsuitable' ? (
              <button
                onClick={handleRunCorrection}
                disabled={isExecuting}
                className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 rounded-lg flex items-center gap-2 shadow-sm transition-colors cursor-pointer shrink-0"
              >
                {isExecuting ? (
                  <>
                    <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                    <span>Synthesizing Correction...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5 fill-current" />
                    <span>Execute API Correction</span>
                  </>
                )}
              </button>
            ) : (
              <div className="flex items-center gap-2">
                <span className="px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs font-semibold flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Correction Active in Memory</span>
                </span>
                <button
                  onClick={onNavigateToHealth}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold transition-colors cursor-pointer"
                >
                  Inspect Health Impact →
                </button>
              </div>
            )}
          </div>

          {/* Success Banner if just executed */}
          {successMessage && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3 flex items-center justify-between text-xs text-emerald-800 animate-in fade-in duration-150">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>{successMessage}</span>
              </div>
              <button
                onClick={onNavigateToHealth}
                className="font-bold underline hover:text-emerald-950 cursor-pointer"
              >
                View System Health Impact →
              </button>
            </div>
          )}

          {/* HOW THE API DATA GETS CORRECTED: 4-STAGE INTERACTIVE VISUALIZER */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-teal-600" />
              <span>Autonomous Correction Mechanism Pipeline</span>
            </h3>

            {/* Stage 1: Inbound Unsuitable API Ingest */}
            <div className="rounded-xl border border-red-200 bg-red-50/30 p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-red-900">
                  <span className="w-5 h-5 rounded-full bg-red-500 text-white flex items-center justify-center text-[10px]">
                    1
                  </span>
                  <span>Inbound Unsuitable API Payload (Detected Anomaly)</span>
                </div>
                <span className="text-[10px] font-mono text-red-700 bg-red-100 px-2 py-0.5 rounded">
                  Status: 400 Bad Request if unhandled
                </span>
              </div>
              <p className="text-[11px] text-slate-600">
                {suitability.detectedIssue}
              </p>
              <pre className="p-3 rounded-lg bg-slate-900 text-red-300 font-mono text-[11px] overflow-x-auto leading-relaxed border border-slate-800">
                {JSON.stringify(suitability.inboundPayload, null, 2)}
              </pre>
            </div>

            {/* Stage 2: Synthesis of Correction Transformer */}
            <div className="rounded-xl border border-teal-200 bg-teal-50/30 p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-teal-900">
                  <span className="w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center text-[10px]">
                    2
                  </span>
                  <span>Synthesis: Transformation Rule & Schema Adapter</span>
                </div>
                <span className="text-[10px] font-mono text-teal-800 bg-teal-100 px-2 py-0.5 rounded">
                  AST Rule: {suitability.correctionStrategy}
                </span>
              </div>
              <div className="p-3 bg-white rounded-lg border border-teal-100 text-[11px] text-slate-700 space-y-1">
                <div>
                  <strong>HealOps Adapter Logic:</strong> Intercept inbound HTTP payload at proxy ingress layer.
                </div>
                <div>
                  <strong>Correction Method:</strong> {suitability.correctionStrategy}.
                </div>
                <div>
                  <strong>Preservation Guarantee:</strong> Backwards compatible; idempotent; zero heap mutation on failure.
                </div>
              </div>
            </div>

            {/* Stage 3: Verification & Invariant Testing */}
            <div className="rounded-xl border border-slate-200 bg-slate-50/60 p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-900">
                  <span className="w-5 h-5 rounded-full bg-slate-800 text-white flex items-center justify-center text-[10px]">
                    3
                  </span>
                  <span>Canary Sandbox Validation</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  100% Invariants Verified
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-[11px]">
                <div className="p-2 bg-white rounded border border-slate-200">
                  <span className="text-slate-500 block text-[10px]">Schema Checks</span>
                  <strong className="text-emerald-700">14/14 Passed</strong>
                </div>
                <div className="p-2 bg-white rounded border border-slate-200">
                  <span className="text-slate-500 block text-[10px]">Validation Latency</span>
                  <strong className="text-teal-700 font-mono">1.2ms</strong>
                </div>
                <div className="p-2 bg-white rounded border border-slate-200">
                  <span className="text-slate-500 block text-[10px]">Data Loss Risk</span>
                  <strong className="text-emerald-700">0.00% (Zero Loss)</strong>
                </div>
              </div>
            </div>

            {/* Stage 4: Corrected & Sanitized API Output */}
            <div className="rounded-xl border border-emerald-200 bg-emerald-50/30 p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-900">
                  <span className="w-5 h-5 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px]">
                    4
                  </span>
                  <span>Corrected & Normalized API Output (Ready for System Ingest)</span>
                </div>
                <span className="text-[10px] font-mono text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                  Status: 200 OK Compliant
                </span>
              </div>
              <p className="text-[11px] text-slate-600">
                Downstream services receive clean, compliant JSON satisfying all schema contracts without downstream crashes.
              </p>
              <pre className="p-3 rounded-lg bg-slate-900 text-emerald-300 font-mono text-[11px] overflow-x-auto leading-relaxed border border-slate-800">
                {JSON.stringify(suitability.correctedPayload, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
