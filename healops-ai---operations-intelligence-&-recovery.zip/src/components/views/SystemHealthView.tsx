import React, { useState } from 'react';
import {
  Activity,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Zap,
  BarChart3,
  Server,
  Layers,
  ArrowUpRight
} from 'lucide-react';
import { CustomerRequest, ServiceStatus } from '../../types';

interface SystemHealthViewProps {
  customerRequests: CustomerRequest[];
  services: ServiceStatus[];
  onNavigateToRecovery: () => void;
}

export const SystemHealthView: React.FC<SystemHealthViewProps> = ({
  customerRequests,
  services,
  onNavigateToRecovery,
}) => {
  const correctedItems = customerRequests.filter(
    (r) => r.apiSuitability.status === 'Corrected' || r.apiSuitability.status === 'Unsuitable'
  );

  const [activeTab, setActiveTab] = useState<'all' | 'latency' | 'errors' | 'business'>('all');
  const [selectedRecord, setSelectedRecord] = useState<CustomerRequest>(correctedItems[0] || customerRequests[0]);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-[#0B1A28] to-[#0A221C] text-white p-6 rounded-2xl border border-slate-800 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <Activity className="w-4 h-4" />
              </span>
              <h1 className="text-xl font-bold tracking-tight">System Health: Corrected Data & Impact Telemetry</h1>
            </div>
            <p className="text-xs text-slate-400 max-w-2xl leading-relaxed">
              Real-time measurement of system stability, throughput improvements, and latency drops achieved by autonomous API data correction.
            </p>
          </div>
          <button
            onClick={onNavigateToRecovery}
            className="px-4 py-2 text-xs font-semibold bg-teal-600 hover:bg-teal-500 text-white rounded-lg shadow-sm transition-all flex items-center gap-2 cursor-pointer shrink-0"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Manage Recovery Center →</span>
          </button>
        </div>
      </div>

      {/* 4 Core Impact KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Uptime Preserved</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-1 tabular-nums font-mono">99.98%</div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-1 flex items-center gap-1">
            <span>↑ Protected vs 91.2% projected drop</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Zero unhandled schema crashes</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Latency Improvement</span>
            <TrendingDown className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-1 tabular-nums font-mono">-98.7%</div>
          <div className="text-[11px] text-teal-600 font-semibold mt-1 flex items-center gap-1">
            <span>42ms avg (from 3,200ms timeout)</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Circuit breakers remained closed</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Error Rate Reduction</span>
            <TrendingDown className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-1 tabular-nums font-mono">0.02%</div>
          <div className="text-[11px] text-emerald-600 font-semibold mt-1 flex items-center gap-1">
            <span>Plummeted from 14.8% inbound errors</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">400 & 422 HTTP exceptions resolved</div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Business SLA Fulfillment</span>
            <CheckCircle2 className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 mt-1 tabular-nums font-mono">100%</div>
          <div className="text-[11px] text-teal-600 font-semibold mt-1 flex items-center gap-1">
            <span>128/128 Customer workflows completed</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">$0 revenue lost to API failures</div>
        </div>
      </div>

      {/* Main Impact Grid: Corrected Data Records Ledger + Impact Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Corrected Data Table (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Corrected Data Records & Live Impact</h2>
              <p className="text-[11px] text-slate-500">
                Select a corrected API transaction to inspect granular before/after metric changes
              </p>
            </div>
            <span className="text-[11px] font-mono font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              {correctedItems.length} Corrected Payloads
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {correctedItems.map((item) => {
              const isSelected = selectedRecord.id === item.id;
              const isCorrected = item.apiSuitability.status === 'Corrected';
              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedRecord(item)}
                  className={`p-4 transition-colors cursor-pointer text-left ${
                    isSelected ? 'bg-teal-50/40 border-l-4 border-teal-600' : 'hover:bg-slate-50/80'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-900">{item.refId}</span>
                      <span className="text-xs font-medium text-slate-700">{item.message}</span>
                    </div>
                    <span
                      className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                        isCorrected
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          : 'bg-amber-50 text-amber-700 border-amber-200'
                      }`}
                    >
                      {isCorrected ? '✓ Live Corrected' : 'Pending Correction'}
                    </span>
                  </div>

                  <div className="mt-2 text-xs text-slate-600 font-mono text-[11px] bg-slate-50 p-2 rounded border border-slate-100">
                    <strong>Corrected Anomaly:</strong> {item.apiSuitability.anomalyType}
                  </div>

                  <div className="mt-2.5 flex items-center gap-4 text-[11px] text-slate-500">
                    <span className="text-teal-700 font-semibold font-mono">
                      ⚡ Latency: {item.apiSuitability.impactMetrics.latencyChange}
                    </span>
                    <span>·</span>
                    <span className="text-emerald-700 font-semibold">
                      SLA: {item.apiSuitability.impactMetrics.uptimePreserved}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Impact Changes Deep-Dive Inspector (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 shadow-xs p-5 space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <span className="text-[10px] font-bold text-teal-700 uppercase tracking-wider">
                Impact Analysis
              </span>
              <h3 className="text-sm font-bold text-slate-900 font-mono">
                {selectedRecord.refId} ({selectedRecord.category})
              </h3>
            </div>
            <span className="text-xs font-medium text-slate-500">
              Customer: {selectedRecord.customerName || 'Direct API'}
            </span>
          </div>

          {/* Granular Impact Changes */}
          <div className="space-y-3">
            {/* 1. Latency Delta */}
            <div className="p-3.5 rounded-xl border border-teal-200/80 bg-teal-50/40 space-y-1">
              <div className="text-[10px] font-bold text-teal-800 uppercase tracking-wide flex items-center justify-between">
                <span>Latency Impact Change</span>
                <span className="font-mono">Real-time</span>
              </div>
              <div className="text-xs font-bold text-teal-950 font-mono">
                {selectedRecord.apiSuitability.impactMetrics.latencyChange}
              </div>
              <div className="text-[11px] text-slate-600">
                Prevented downstream socket hang-up and downstream consumer retry cascades.
              </div>
            </div>

            {/* 2. Error Rate Delta */}
            <div className="p-3.5 rounded-xl border border-emerald-200/80 bg-emerald-50/40 space-y-1">
              <div className="text-[10px] font-bold text-emerald-800 uppercase tracking-wide flex items-center justify-between">
                <span>Error Rate & Exception Impact</span>
                <span className="font-mono">Invariants OK</span>
              </div>
              <div className="text-xs font-bold text-emerald-950">
                {selectedRecord.apiSuitability.impactMetrics.errorRateChange}
              </div>
              <div className="text-[11px] text-slate-600">
                Ingestion transformed 100% of rejected payloads into schema-compliant records.
              </div>
            </div>

            {/* 3. Throughput & Throughput Delta */}
            <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
              <div className="text-[10px] font-bold text-slate-600 uppercase tracking-wide">
                Throughput & Processing Impact
              </div>
              <div className="text-xs font-bold text-slate-900 font-mono">
                {selectedRecord.apiSuitability.impactMetrics.throughputChange}
              </div>
              <div className="text-[11px] text-slate-600">
                Worker queue depth normalized without backpressure stalling.
              </div>
            </div>

            {/* 4. Business Impact */}
            <div className="p-3.5 rounded-xl border border-blue-200 bg-blue-50/40 space-y-1">
              <div className="text-[10px] font-bold text-blue-800 uppercase tracking-wide">
                Business & End-User Impact
              </div>
              <div className="text-xs font-bold text-blue-950">
                {selectedRecord.apiSuitability.impactMetrics.businessImpact}
              </div>
              <div className="text-[11px] text-slate-600">
                Customer received immediate fulfillment without seeing an error screen.
              </div>
            </div>
          </div>

          {/* Corrected Payload Ingestion Verification */}
          <div className="pt-2">
            <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-2">
              Ingested Corrected Payload Verification
            </div>
            <pre className="p-3 rounded-xl bg-slate-900 text-emerald-300 font-mono text-[11px] overflow-x-auto leading-relaxed border border-slate-800 max-h-48">
              {JSON.stringify(selectedRecord.apiSuitability.correctedPayload, null, 2)}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
