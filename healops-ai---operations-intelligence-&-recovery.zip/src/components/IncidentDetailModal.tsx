import React, { useState } from 'react';
import { X, ShieldCheck, AlertCircle, CheckCircle2, RefreshCw, Cpu, Code2, ArrowRight } from 'lucide-react';
import { IncidentItem } from '../types';

interface IncidentDetailModalProps {
  incident: IncidentItem | null;
  onClose: () => void;
  onResolve: (id: string) => void;
}

export const IncidentDetailModal: React.FC<IncidentDetailModalProps> = ({
  incident,
  onClose,
  onResolve,
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'payload' | 'logs'>('overview');
  const [isFixing, setIsFixing] = useState(false);

  if (!incident) return null;

  const handleFix = () => {
    setIsFixing(true);
    setTimeout(() => {
      setIsFixing(false);
      onResolve(incident.id);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs font-bold px-2 py-0.5 rounded bg-teal-500/20 text-teal-300 border border-teal-500/30">
              {incident.id}
            </span>
            <div>
              <h2 className="text-sm font-bold tracking-tight">
                {incident.workflow} · {incident.failureType}
              </h2>
              <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                <span>Detected at {incident.detectedAt}</span>
                <span>·</span>
                <span>Severity: {incident.severity}</span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="px-6 pt-3 bg-slate-50 border-b border-slate-200 flex items-center gap-4 text-xs">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-2.5 font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'overview'
                ? 'border-teal-600 text-teal-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Root Cause & Strategy
          </button>
          <button
            onClick={() => setActiveTab('payload')}
            className={`pb-2.5 font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'payload'
                ? 'border-teal-600 text-teal-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Payload & Schema Diff
          </button>
          <button
            onClick={() => setActiveTab('logs')}
            className={`pb-2.5 font-medium border-b-2 transition-colors cursor-pointer ${
              activeTab === 'logs'
                ? 'border-teal-600 text-teal-800'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Execution Logs & Trace
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1 text-xs text-slate-700">
          {activeTab === 'overview' && (
            <div className="space-y-4">
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">
                  Root Cause Analysis
                </div>
                <p className="text-xs text-slate-800 mt-1.5 leading-relaxed font-medium">
                  {incident.rootCause ||
                    'Upstream webhook response contained unanticipated schema key alterations causing serialization failure in parser.'}
                </p>
              </div>

              <div className="bg-teal-50/60 rounded-xl p-4 border border-teal-200/80">
                <div className="text-[11px] font-bold text-teal-800 uppercase tracking-wide flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5" />
                  <span>Automated Healing Strategy</span>
                </div>
                <p className="text-xs text-teal-900 mt-1.5 leading-relaxed">
                  {incident.suggestedPatch ||
                    'Synthesizing dynamic runtime field transformer adapter with schema validation before rerouting.'}
                </p>
                <div className="mt-3 flex items-center gap-4 text-[11px] text-teal-700">
                  <span>Diagnostic confidence: <strong>99.2%</strong></span>
                  <span>·</span>
                  <span>Affected clients: <strong>{incident.affectedCustomers ?? 3}</strong></span>
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl p-4">
                <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wide mb-2">
                  Validation Checklist
                </div>
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-2 text-emerald-700">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>Schema invariant check: PASSED</span>
                  </div>
                  <div className="flex items-center gap-2 text-emerald-700">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>Idempotency token verified: PASSED</span>
                  </div>
                  <div className="flex items-center gap-2 text-emerald-700">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>Canary dry-run payload execution: 100% success</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'payload' && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-red-50/50 border border-red-200 rounded-xl p-3">
                  <div className="text-[10px] font-bold text-red-700 uppercase tracking-wider mb-2">
                    - Inbound Payload (Failed)
                  </div>
                  <pre className="font-mono text-[11px] text-red-950 bg-white/70 p-2.5 rounded border border-red-100 overflow-x-auto">
{`{
  "order_id": "ORD-10023",
  "customer": {
    "full_name": "Alex Mercer"
  },
  "status": "pending_dispatch"
}`}
                  </pre>
                </div>
                <div className="bg-emerald-50/50 border border-emerald-200 rounded-xl p-3">
                  <div className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider mb-2">
                    + Healed Payload (Normalized)
                  </div>
                  <pre className="font-mono text-[11px] text-emerald-950 bg-white/70 p-2.5 rounded border border-emerald-100 overflow-x-auto">
{`{
  "order_id": "ORD-10023",
  "customer_name": "Alex Mercer",
  "customer": {
    "full_name": "Alex Mercer"
  },
  "status": "pending_dispatch"
}`}
                  </pre>
                </div>
              </div>
              <div className="text-[11px] text-slate-500 italic">
                * HealOps AI injected a zero-latency bidirectional alias adapter to reconcile backward and forward schema compatibility.
              </div>
            </div>
          )}

          {activeTab === 'logs' && (
            <div className="bg-slate-900 rounded-xl p-4 font-mono text-[11px] text-slate-300 space-y-1.5 max-h-60 overflow-y-auto">
              <div className="text-slate-500">[12:42:01.102] POST /api/v2/orders/ingest HTTP/1.1 400 Bad Request</div>
              <div className="text-red-400">[12:42:01.105] ValidationError: missing required property 'customer_name'</div>
              <div className="text-slate-400">[12:42:01.150] HealOps Sentinel intercepted failure: INC-0042 recorded</div>
              <div className="text-cyan-400">[12:42:01.210] Diagnostic engine invoked: AST difference mapped to alias pattern #42</div>
              <div className="text-teal-400">[12:42:01.420] Synthesizing schema adapter in test sandbox...</div>
              <div className="text-emerald-400">[12:42:01.590] Canary probe: 10/10 mock payloads passed</div>
              <div className="text-emerald-300">[12:42:01.620] Applying self-healing patch to router memory</div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
          >
            Close
          </button>
          <button
            onClick={handleFix}
            disabled={isFixing}
            className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 rounded-lg flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
          >
            {isFixing ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Applying Auto-Recovery...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Trigger Auto-Recovery & Resolve</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
