import React from 'react';
import { AlertCircle, Check } from 'lucide-react';
import { RecoveryStep } from '../types';

interface LiveRecoveryActivityProps {
  steps: RecoveryStep[];
  onStepClick?: (step: RecoveryStep) => void;
}

export const LiveRecoveryActivity: React.FC<LiveRecoveryActivityProps> = ({
  steps,
  onStepClick,
}) => {
  // Show key recent steps to avoid overwhelming vertical scroll
  const displaySteps = steps.slice(0, 5);

  return (
    <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-5">
      {/* Header without extra button */}
      <div className="mb-4 pb-2 border-b border-slate-100">
        <h3 className="text-sm font-bold text-slate-900 tracking-tight">Live Recovery Activity</h3>
        <p className="text-[11px] text-slate-400">Autonomous self-healing lifecycle events</p>
      </div>

      {/* Stepper Timeline */}
      <div className="relative pl-6 space-y-4 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-gradient-to-b before:from-red-400 before:via-teal-400 before:to-emerald-500">
        {displaySteps.map((step, idx) => {
          let nodeIcon = null;
          let nodeClass = '';

          if (step.type === 'alert') {
            nodeClass = 'bg-red-500 text-white ring-4 ring-red-100';
            nodeIcon = <AlertCircle className="w-3 h-3 stroke-[2.5]" />;
          } else if (step.type === 'verified' || step.type === 'closed') {
            nodeClass = 'bg-emerald-500 text-white ring-4 ring-emerald-100';
            nodeIcon = <Check className="w-3 h-3 stroke-[2.5]" />;
          } else {
            nodeClass = 'bg-teal-500 text-white ring-4 ring-teal-100';
            nodeIcon = <div className="w-1.5 h-1.5 rounded-full bg-white"></div>;
          }

          return (
            <div
              key={step.id || idx}
              onClick={() => onStepClick && onStepClick(step)}
              className="relative flex items-start gap-3 group cursor-pointer"
            >
              {/* Timeline Node */}
              <div
                className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center shrink-0 transition-transform group-hover:scale-110 ${nodeClass}`}
              >
                {nodeIcon}
              </div>

              {/* Timestamp */}
              <span className="font-mono text-[11px] text-slate-400 font-normal shrink-0 pt-0.5 tabular-nums w-9">
                {step.time}
              </span>

              {/* Text content */}
              <div className="flex-1 min-w-0">
                <div className="text-xs font-semibold text-slate-900 leading-tight group-hover:text-teal-700 transition-colors">
                  {step.title}
                </div>
                <div className="text-[11px] text-slate-400 leading-tight mt-0.5 truncate">
                  {step.subtitle}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
