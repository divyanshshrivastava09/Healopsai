import React, { useState } from 'react';
import { Bell, Play, CheckCircle2, AlertTriangle, ShieldCheck, X } from 'lucide-react';

interface TopNavProps {
  onRunDemo: () => void;
  systemHealthy: boolean;
  notificationCount: number;
  onClearNotifications: () => void;
}

export const TopNav: React.FC<TopNavProps> = ({
  onRunDemo,
  systemHealthy,
  notificationCount,
  onClearNotifications,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);

  const notifications = [
    {
      id: 1,
      title: 'Auto-Recovery Verified for INC-0042',
      time: '2 min ago',
      desc: 'Schema field alias applied to Order Service.',
      type: 'success'
    },
    {
      id: 2,
      title: 'Degraded State: Order Processing Service',
      time: '5 min ago',
      desc: '2 burst retry timeouts detected. Healing in progress.',
      type: 'warning'
    },
    {
      id: 3,
      title: 'Approval Pending for Invoice Pipeline',
      time: '32 min ago',
      desc: 'Accounting gateway 502 requires confirmation.',
      type: 'alert'
    }
  ];

  return (
    <>
      {/* Dark Top Bar matching reference */}
      <header className="h-14 bg-[#0A1118] border-b border-slate-800/60 px-6 flex items-center justify-end gap-5 shrink-0 z-20">
        {/* System Healthy Status Pill */}
        <div className="flex items-center gap-2 bg-[#09221C] border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-medium text-emerald-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block shadow-sm shadow-emerald-400/50"></span>
          <span>System Healthy</span>
        </div>

        {/* Notifications Popover */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="relative p-2 text-slate-300 hover:text-white hover:bg-slate-800/60 rounded-lg transition-colors"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            {notificationCount > 0 && (
              <span className="absolute 1 top-1.5 right-1.5 w-4 h-4 bg-red-500 text-white rounded-full text-[10px] font-bold flex items-center justify-center leading-none ring-2 ring-[#0A1118]">
                {notificationCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-slate-900 border border-slate-800 rounded-xl shadow-2xl p-4 text-xs z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-200 font-semibold">
                <span>Recent System Alerts</span>
                <button
                  onClick={() => {
                    onClearNotifications();
                    setShowNotifications(false);
                  }}
                  className="text-[11px] text-teal-400 hover:underline font-normal"
                >
                  Clear all
                </button>
              </div>
              <div className="divide-y divide-slate-800 mt-2 space-y-2">
                {notifications.map((n) => (
                  <div key={n.id} className="pt-2 first:pt-0">
                    <div className="flex items-start justify-between gap-1">
                      <span className="font-medium text-slate-100">{n.title}</span>
                      <span className="text-[10px] text-slate-400 shrink-0">{n.time}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">{n.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User Profile in Top Bar */}
        <div className="flex items-center gap-2.5 pl-2 border-l border-slate-800/60">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-600 to-blue-500 text-white font-semibold text-xs flex items-center justify-center ring-1 ring-white/20">
            RS
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-semibold text-slate-100 leading-tight">Riya Sharma</span>
            <span className="text-[10px] text-slate-400 leading-tight">Product Engineer</span>
          </div>
        </div>
      </header>
    </>
  );
};
