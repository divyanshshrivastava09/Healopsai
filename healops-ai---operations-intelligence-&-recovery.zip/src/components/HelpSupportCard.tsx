import React from 'react';
import { HelpCircle } from 'lucide-react';

interface HelpSupportCardProps {
  onContactSupport: () => void;
}

export const HelpSupportCard: React.FC<HelpSupportCardProps> = ({ onContactSupport }) => {
  return (
    <div className="bg-[#F8FAFD] rounded-xl border border-slate-200/90 shadow-xs p-4 flex items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-sm shrink-0">
          ?
        </div>
        <div>
          <div className="text-xs font-bold text-slate-900 leading-tight">Need more help?</div>
          <div className="text-[11px] text-slate-500 leading-tight mt-0.5">
            Our support team is available 24/7.
          </div>
        </div>
      </div>
      <button
        onClick={onContactSupport}
        className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg shadow-2xs hover:border-slate-300 transition-all shrink-0 cursor-pointer"
      >
        Contact Support
      </button>
    </div>
  );
};
