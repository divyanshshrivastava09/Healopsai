import React from 'react';
import { X, MessageSquare, CheckCircle2, User, Clock, ArrowRight, AlertTriangle, Cpu, Activity } from 'lucide-react';
import { CustomerRequest } from '../types';

interface CustomerRequestDetailModalProps {
  request: CustomerRequest | null;
  onClose: () => void;
  onNavigateToRecovery?: (req: CustomerRequest) => void;
  onNavigateToHealth?: (req: CustomerRequest) => void;
}

export const CustomerRequestDetailModal: React.FC<CustomerRequestDetailModalProps> = ({
  request,
  onClose,
  onNavigateToRecovery,
  onNavigateToHealth,
}) => {
  if (!request) return null;

  const suitability = request.apiSuitability;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-xl w-full shadow-2xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-teal-50 text-teal-700">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">Request #{request.id}</h3>
              <p className="text-[11px] text-slate-500">Customer message & API anomaly detection</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-4 space-y-4 text-xs">
          {/* Main Request Info */}
          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">"{request.message}"</span>
              <span
                className={`px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                  request.status === 'Resolved'
                    ? 'bg-emerald-100 text-emerald-800'
                    : request.status === 'In Progress'
                    ? 'bg-blue-100 text-blue-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {request.status}
              </span>
            </div>
            <div className="text-[11px] text-slate-500 flex items-center gap-3">
              <span>Category: <strong>{request.category}</strong></span>
              <span>·</span>
              <span>Ref: <strong className="font-mono">{request.refId}</strong></span>
              <span>·</span>
              <span>Timestamp: <strong>{request.timestamp || 'Today'}</strong></span>
            </div>
          </div>

          {/* API Data Suitability Detection Section */}
          <div className={`p-4 rounded-xl border space-y-2.5 ${
            suitability.status === 'Unsuitable'
              ? 'bg-red-50/40 border-red-200'
              : suitability.status === 'Corrected'
              ? 'bg-emerald-50/40 border-emerald-200'
              : 'bg-slate-50 border-slate-200'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold text-xs">
                {suitability.status === 'Unsuitable' ? (
                  <>
                    <AlertTriangle className="w-4 h-4 text-red-600" />
                    <span className="text-red-900">API Data Suitability: Unsuitable Anomaly Detected</span>
                  </>
                ) : suitability.status === 'Corrected' ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span className="text-emerald-900">API Data Suitability: Auto-Corrected via Recovery</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4 text-slate-600" />
                    <span className="text-slate-800">API Data Suitability: Compliant Schema</span>
                  </>
                )}
              </div>
              <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-white font-semibold border border-slate-200">
                {suitability.anomalyType}
              </span>
            </div>

            <p className="text-[11px] text-slate-700 leading-relaxed">
              <strong>Detected Issue:</strong> {suitability.detectedIssue}
            </p>

            <div className="bg-slate-900 p-2.5 rounded-lg text-slate-200 font-mono text-[10px] overflow-x-auto">
              <div className="text-slate-400 mb-1">// Inbound API Payload:</div>
              {JSON.stringify(suitability.inboundPayload, null, 2)}
            </div>

            {/* Quick Action Navigation */}
            <div className="pt-2 flex items-center justify-end gap-2">
              {suitability.status === 'Unsuitable' && onNavigateToRecovery && (
                <button
                  onClick={() => {
                    onClose();
                    onNavigateToRecovery(request);
                  }}
                  className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <Cpu className="w-3.5 h-3.5" />
                  <span>Correct Data in Recovery Center →</span>
                </button>
              )}

              {suitability.status === 'Corrected' && onNavigateToHealth && (
                <button
                  onClick={() => {
                    onClose();
                    onNavigateToHealth(request);
                  }}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>Inspect System Health Impact →</span>
                </button>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-[11px] font-bold text-slate-500 uppercase">Resolution Path</div>
            <div className="p-3 bg-teal-50/60 rounded-xl border border-teal-100 text-teal-900 leading-relaxed">
              <strong>Outcome:</strong> {request.resolution}. Ingestion pipelines secured against schema anomalies.
            </div>
          </div>
        </div>

        <div className="mt-5 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
