import React, { useState, useEffect } from 'react';
import { Play, CheckCircle2, AlertTriangle, ArrowRight, X, Cpu, ShieldCheck, RefreshCw, Zap } from 'lucide-react';

interface DemoScenarioModalProps {
  isOpen: boolean;
  onClose: () => void;
  onApplyScenario: () => void;
}

export const DemoScenarioModal: React.FC<DemoScenarioModalProps> = ({
  isOpen,
  onClose,
  onApplyScenario,
}) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  const scenarioSteps = [
    {
      title: 'Simulate Injected Failure',
      desc: 'Deploy mock schema contract mismatch to Order Processing Service webhook ingest.',
      status: 'Payload key mismatch: "customer" vs "customer_name"',
      badge: 'Failure Injected',
      badgeColor: 'bg-red-50 text-red-700 border-red-200'
    },
    {
      title: 'AI Diagnostic Telemetry',
      desc: 'HealOps diagnostic agent inspects payload trace and detects schema mapping desync.',
      status: 'Root cause confidence: 99.4% (Field alias required)',
      badge: 'Diagnosed',
      badgeColor: 'bg-blue-50 text-blue-700 border-blue-200'
    },
    {
      title: 'Autonomous Patch Synthesis',
      desc: 'Synthesizing dynamic runtime field transformer adapter in sandbox.',
      status: 'Adapter: mapping "customer" -> "customer_name" compiled',
      badge: 'Patch Generated',
      badgeColor: 'bg-teal-50 text-teal-700 border-teal-200'
    },
    {
      title: 'Canary Verification & Validation',
      desc: 'Executing test transactions against canary sandbox before production rollout.',
      status: 'All 15 verification assertions passed (0 errors, 42ms latency)',
      badge: 'Validated',
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200'
    },
    {
      title: 'Self-Healing Recovery Complete',
      desc: 'Order Service recovered to 100% healthy status. INC-0042 auto-closed.',
      status: 'Zero downtime observed by end users.',
      badge: 'Recovered',
      badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200'
    }
  ];

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isRunning && currentStep < scenarioSteps.length) {
      timer = setTimeout(() => {
        if (currentStep + 1 < scenarioSteps.length) {
          setCurrentStep((prev) => prev + 1);
        } else {
          setIsRunning(false);
          setIsCompleted(true);
        }
      }, 1400);
    }
    return () => clearTimeout(timer);
  }, [isRunning, currentStep]);

  if (!isOpen) return null;

  const handleStart = () => {
    setCurrentStep(0);
    setIsCompleted(false);
    setIsRunning(true);
  };

  const handleFinish = () => {
    onApplyScenario();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-xl w-full shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-teal-500/20 text-teal-400 flex items-center justify-center border border-teal-500/30">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold tracking-tight">Run Demo Self-Healing Scenario</h2>
              <p className="text-[11px] text-slate-400">Simulate end-to-end incident discovery and auto-recovery</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5">
          <div className="bg-[#F0FDF4] border border-emerald-200/80 rounded-xl p-3.5 flex items-center gap-3 text-xs text-emerald-800">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>
              This simulation injects a realistic schema mismatch in Order Processing Service, tracks AI diagnosis, compiles an automated recovery patch, and verifies restored output.
            </span>
          </div>

          {/* Stepper Progress */}
          <div className="space-y-3">
            {scenarioSteps.map((step, idx) => {
              const isPast = idx < currentStep || isCompleted;
              const isCurrent = idx === currentStep && isRunning;
              return (
                <div
                  key={step.title}
                  className={`p-3.5 rounded-xl border transition-all ${
                    isCurrent
                      ? 'bg-teal-50/50 border-teal-300 ring-1 ring-teal-200'
                      : isPast
                      ? 'bg-slate-50/70 border-slate-200/80'
                      : 'bg-white border-slate-100 opacity-60'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-mono ${
                          isPast
                            ? 'bg-emerald-500 text-white'
                            : isCurrent
                            ? 'bg-teal-500 text-white animate-pulse'
                            : 'bg-slate-200 text-slate-600'
                        }`}
                      >
                        {isPast ? <CheckCircle2 className="w-3.5 h-3.5" /> : idx + 1}
                      </div>
                      <span className="text-xs font-bold text-slate-900">{step.title}</span>
                    </div>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${step.badgeColor}`}>
                      {step.badge}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 mt-1 pl-8">{step.desc}</p>
                  {(isCurrent || isPast) && (
                    <div className="mt-2 pl-8 text-[11px] font-mono text-teal-800 bg-teal-50/80 px-2.5 py-1 rounded border border-teal-100">
                      {step.status}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
          >
            Cancel
          </button>
          {!isCompleted ? (
            <button
              onClick={handleStart}
              disabled={isRunning}
              className="px-4 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 disabled:opacity-50 rounded-lg flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              {isRunning ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Executing Scenario...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Start Live Scenario</span>
                </>
              )}
            </button>
          ) : (
            <button
              onClick={handleFinish}
              className="px-4 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg flex items-center gap-2 shadow-xs transition-colors cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Apply to Dashboard State</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
