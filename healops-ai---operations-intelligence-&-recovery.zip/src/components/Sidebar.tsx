import React from 'react';
import {
  LayoutDashboard,
  Headphones,
  PackageSearch,
  RotateCcw,
  Ticket,
  GitMerge,
  ShieldAlert,
  Cpu,
  Activity,
  History,
  Layers,
  Settings,
  ChevronDown,
  Sparkles,
  Sliders
} from 'lucide-react';
import { NavigationTab } from '../types';

interface SidebarProps {
  activeTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  onOpenSettings: () => void;
  systemHealthy: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  onOpenSettings,
  systemHealthy
}) => {
  const customerOperationsNav = [
    { id: 'operations-overview' as NavigationTab, label: 'Operations Overview', icon: LayoutDashboard },
    { id: 'customer-support' as NavigationTab, label: 'Customer Support', icon: Headphones },
    { id: 'order-tracking' as NavigationTab, label: 'Order Tracking', icon: PackageSearch },
    { id: 'refund-support' as NavigationTab, label: 'Refund Support', icon: RotateCcw },
  ];

  const systemIntelligenceNav = [
    { id: 'workflow-monitor' as NavigationTab, label: 'Workflow Monitor', icon: GitMerge },
    { id: 'incident-intelligence' as NavigationTab, label: 'Incident Intelligence', icon: ShieldAlert },
    { id: 'recovery-center' as NavigationTab, label: 'Recovery Center', icon: Cpu },
    { id: 'system-health' as NavigationTab, label: 'System Health', icon: Activity },
    { id: 'recovery-history' as NavigationTab, label: 'Recovery History', icon: History },
    { id: 'system-architecture' as NavigationTab, label: 'System Architecture', icon: Layers },
  ];

  return (
    <aside className="w-64 bg-[#0A1118] text-slate-300 flex flex-col shrink-0 border-r border-slate-800/60 select-none min-h-screen">
      {/* Brand Header */}
      <div className="p-5 flex items-start gap-3 border-b border-slate-800/40">
        <div className="relative flex items-center justify-center w-9 h-9 rounded-xl bg-gradient-to-tr from-teal-500 to-cyan-400 p-0.5 shadow-lg shadow-teal-500/20 shrink-0">
          <div className="w-full h-full bg-[#0A1118] rounded-[10px] flex items-center justify-center">
            <div className="w-4 h-4 rounded-full border-2 border-teal-400 border-t-transparent animate-spin-slow"></div>
            <div className="absolute w-1.5 h-1.5 bg-teal-300 rounded-full"></div>
          </div>
        </div>
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className="text-white font-bold text-base tracking-tight">HealOps AI</span>
          </div>
          <span className="text-[11px] text-slate-400 font-normal leading-snug">
            Your workflows, resilient by design.
          </span>
        </div>
      </div>

      {/* Nav Content */}
      <div className="flex-1 px-3 py-4 space-y-6 overflow-y-auto">
        {/* Customer Operations Section */}
        <div>
          <div className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase px-3 mb-2">
            CUSTOMER OPERATIONS
          </div>
          <nav className="space-y-1">
            {customerOperationsNav.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-lg transition-all text-left ${
                    isActive
                      ? 'bg-[#132837] text-teal-300 border border-teal-500/30 shadow-sm shadow-teal-900/30'
                      : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/40'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-teal-400' : 'text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* System Intelligence Section */}
        <div>
          <div className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase px-3 mb-2">
            SYSTEM INTELLIGENCE
          </div>
          <nav className="space-y-1">
            {systemIntelligenceNav.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onSelectTab(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-medium rounded-lg transition-all text-left ${
                    isActive
                      ? 'bg-[#132837] text-teal-300 border border-teal-500/30 shadow-sm shadow-teal-900/30'
                      : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/40'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-teal-400' : 'text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Sidebar Footer */}
      <div className="p-3 border-t border-slate-800/50 space-y-3 bg-[#080E14]">
        {/* Simulated Environment Badge */}
        <div className="bg-[#0e212f]/70 border border-teal-500/20 rounded-lg p-2.5 flex items-start gap-2.5">
          <div className="p-1 rounded bg-teal-500/10 text-teal-400 mt-0.5 shrink-0">
            <Sliders className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="text-[10px] font-bold text-teal-300 tracking-wider uppercase">
              SIMULATED ENVIRONMENT
            </div>
            <div className="text-[10px] text-slate-400 leading-tight mt-0.5">
              Demo data · No real customer data
            </div>
          </div>
        </div>

        {/* System Health Quick indicator */}
        <div className="flex items-center justify-between px-2 py-1 text-xs">
          <div className="flex items-center gap-2">
            <span className="relative flex h-2 w-2">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${systemHealthy ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${systemHealthy ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
            </span>
            <span className="text-[11px] text-slate-400">System Health</span>
          </div>
          <span className="text-[11px] font-medium text-emerald-400">
            {systemHealthy ? 'Operational' : 'Degraded'}
          </span>
        </div>

        {/* Settings button */}
        <button
          onClick={onOpenSettings}
          className="w-full flex items-center gap-3 px-3 py-1.5 text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 rounded-lg transition-colors"
        >
          <Settings className="w-4 h-4" />
          <span>Settings</span>
        </button>

        {/* User Card */}
        <div className="pt-2 border-t border-slate-800/40 flex items-center justify-between px-1">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-600 to-blue-500 text-white font-semibold text-xs flex items-center justify-center ring-1 ring-white/20 shadow-sm">
              RS
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-medium text-slate-200 leading-none">Riya Sharma</span>
              <span className="text-[10px] text-slate-400 mt-1 leading-none">Product Engineer</span>
            </div>
          </div>
          <button className="text-slate-400 hover:text-slate-200 p-1 rounded transition-colors" title="User menu">
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
};
