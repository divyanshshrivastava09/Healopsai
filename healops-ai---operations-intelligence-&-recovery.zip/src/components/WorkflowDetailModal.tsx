import React from 'react';
import { X, Activity, CheckCircle2, AlertTriangle, Clock, RefreshCw } from 'lucide-react';
import { WorkflowItem } from '../types';

interface WorkflowDetailModalProps {
  workflow: WorkflowItem | null;
  onClose: () => void;
}

export const WorkflowDetailModal: React.FC<WorkflowDetailModalProps> = ({ workflow, onClose }) => {
  if (!workflow) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl border border-slate-200 max-w-lg w-full shadow-2xl p-6">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-teal-50 text-teal-700">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">{workflow.name}</h3>
              <p className="text-[11px] text-slate-500">Service telemetry & execution breakdown</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="mt-4 space-y-4 text-xs">
          <div className="grid grid-cols-3 gap-2">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Uptime</div>
              <div className="text-sm font-bold text-slate-900 font-mono mt-0.5">{workflow.uptime}</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Avg Latency</div>
              <div className="text-sm font-bold text-slate-900 font-mono mt-0.5">{workflow.avgLatency}</div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100">
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Failures (1h)</div>
              <div className="text-sm font-bold text-slate-900 font-mono mt-0.5">{workflow.recentFailures}</div>
            </div>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800">Operational Health Status</span>
              <span
                className={`px-2 py-0.5 rounded text-[11px] font-semibold ${
                  workflow.health === 'Healthy'
                    ? 'bg-emerald-100 text-emerald-800'
                    : workflow.health === 'Degraded'
                    ? 'bg-amber-100 text-amber-800'
                    : 'bg-red-100 text-red-800'
                }`}
              >
                {workflow.health}
              </span>
            </div>
            <p className="text-[11px] text-slate-600">
              Recovery status: <strong>{workflow.recoveryStatus !== '—' ? workflow.recoveryStatus : 'Nominal'}</strong>.
              Last execution recorded at {workflow.lastExecution}.
            </p>
          </div>

          <div className="space-y-1.5">
            <div className="text-[11px] font-bold text-slate-500 uppercase">Recent Execution Events</div>
            <div className="text-[11px] space-y-1 font-mono text-slate-600">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>[12:48:12] POST /v1/dispatch</span>
                <span className="text-emerald-600">200 OK (38ms)</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>[12:46:04] POST /v1/dispatch</span>
                <span className="text-emerald-600">200 OK (42ms)</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span>[12:42:10] POST /v1/dispatch</span>
                <span className="text-amber-600">Auto-Healed (112ms)</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-5 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
