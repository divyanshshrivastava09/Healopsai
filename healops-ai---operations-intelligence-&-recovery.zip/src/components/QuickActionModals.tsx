import React, { useState } from 'react';
import { X, Search, CheckCircle2, Package, RotateCcw, Send, Settings, Sliders } from 'lucide-react';

interface QuickActionModalsProps {
  trackOrderOpen: boolean;
  onCloseTrackOrder: () => void;
  checkRefundOpen: boolean;
  onCloseCheckRefund: () => void;
  contactSupportOpen: boolean;
  onCloseContactSupport: () => void;
  settingsOpen: boolean;
  onCloseSettings: () => void;
}

export const QuickActionModals: React.FC<QuickActionModalsProps> = ({
  trackOrderOpen,
  onCloseTrackOrder,
  checkRefundOpen,
  onCloseCheckRefund,
  contactSupportOpen,
  onCloseContactSupport,
  settingsOpen,
  onCloseSettings,
}) => {
  // Order tracking state
  const [orderQuery, setOrderQuery] = useState('ORD-10023');
  const [orderFound, setOrderFound] = useState(true);

  // Refund tracking state
  const [refundQuery, setRefundQuery] = useState('REF-5521');

  // Contact support form
  const [chatMsg, setChatMsg] = useState('');
  const [chatSent, setChatSent] = useState(false);

  // Settings
  const [autoHealEnabled, setAutoHealEnabled] = useState(true);
  const [canaryVerification, setCanaryVerification] = useState(true);
  const [notificationAlerts, setNotificationAlerts] = useState(true);

  return (
    <>
      {/* 1. Track an Order Modal */}
      {trackOrderOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full shadow-2xl p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Package className="w-5 h-5 text-teal-600" />
                <h3 className="text-sm font-bold text-slate-900">Track an Order</h3>
              </div>
              <button onClick={onCloseTrackOrder} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={orderQuery}
                  onChange={(e) => setOrderQuery(e.target.value)}
                  placeholder="Enter Order ID (e.g. ORD-10023)"
                  className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-teal-500 font-mono"
                />
                <button
                  onClick={() => setOrderFound(orderQuery.trim().length > 0)}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg cursor-pointer"
                >
                  Lookup
                </button>
              </div>

              {orderFound && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-xs space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-200/60 pb-2">
                    <span className="font-semibold text-slate-900 font-mono">{orderQuery}</span>
                    <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-100 text-emerald-800">
                      Dispatched
                    </span>
                  </div>
                  <div className="text-slate-600 space-y-1 text-[11px]">
                    <div><strong>Customer:</strong> Alex Mercer</div>
                    <div><strong>Courier:</strong> Express Carrier #94012</div>
                    <div><strong>Estimated Delivery:</strong> Tomorrow by 4:00 PM</div>
                    <div><strong>Workflow Node:</strong> Order Processing Service (Verified)</div>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={onCloseTrackOrder}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. Check Refund Status Modal */}
      {checkRefundOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full shadow-2xl p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-teal-600" />
                <h3 className="text-sm font-bold text-slate-900">Check Refund Status</h3>
              </div>
              <button onClick={onCloseCheckRefund} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={refundQuery}
                  onChange={(e) => setRefundQuery(e.target.value)}
                  placeholder="Enter Refund ID (e.g. REF-5521)"
                  className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-teal-500 font-mono"
                />
                <button className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-lg cursor-pointer">
                  Search
                </button>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                  <span className="font-semibold text-slate-900 font-mono">{refundQuery}</span>
                  <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-blue-100 text-blue-800">
                    Processing
                  </span>
                </div>
                <div className="text-slate-600 space-y-1 text-[11px]">
                  <div><strong>Customer:</strong> Sarah Jenkins</div>
                  <div><strong>Refund Amount:</strong> $142.50 USD</div>
                  <div><strong>Gateway:</strong> Stripe Payments v2</div>
                  <div><strong>Automated Step:</strong> Field alias mapped; pending settlement batch.</div>
                </div>
              </div>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={onCloseCheckRefund}
                className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3. Contact Support Modal */}
      {contactSupportOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full shadow-2xl p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs">
                  ?
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Operations Desk Assistance</h3>
                  <p className="text-[11px] text-slate-400">Available 24/7 for critical escalation</p>
                </div>
              </div>
              <button onClick={onCloseContactSupport} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            {chatSent ? (
              <div className="py-6 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto" />
                <h4 className="text-sm font-bold text-slate-900">Message Dispatched</h4>
                <p className="text-xs text-slate-500">
                  Duty Engineer on rotation has received your note. Expected response time: &lt; 2 minutes.
                </p>
                <button
                  onClick={() => {
                    setChatSent(false);
                    onCloseContactSupport();
                  }}
                  className="mt-2 px-4 py-1.5 bg-teal-600 text-white text-xs font-semibold rounded-lg"
                >
                  Dismiss
                </button>
              </div>
            ) : (
              <div className="mt-4 space-y-3 text-xs">
                <p className="text-slate-600">
                  Need assistance with an unrecovered pipeline or anomalous customer request? Send a direct dispatch to the on-call reliability engineer.
                </p>
                <textarea
                  rows={4}
                  value={chatMsg}
                  onChange={(e) => setChatMsg(e.target.value)}
                  placeholder="Describe the issue or incident identifier..."
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-teal-500"
                />
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    onClick={onCloseContactSupport}
                    className="px-4 py-2 text-slate-600 hover:text-slate-900"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => {
                      if (chatMsg.trim()) setChatSent(true);
                    }}
                    className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded-lg flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send Dispatch</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 4. Settings Modal */}
      {settingsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl border border-slate-200 max-w-md w-full shadow-2xl p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-slate-700" />
                <h3 className="text-sm font-bold text-slate-900">Platform Settings</h3>
              </div>
              <button onClick={onCloseSettings} className="text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs">
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <div>
                  <div className="font-semibold text-slate-900">Autonomous Healing Engine</div>
                  <div className="text-[11px] text-slate-500">Auto-apply non-breaking schema field adapters</div>
                </div>
                <input
                  type="checkbox"
                  checked={autoHealEnabled}
                  onChange={(e) => setAutoHealEnabled(e.target.checked)}
                  className="w-4 h-4 accent-teal-600 rounded"
                />
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <div>
                  <div className="font-semibold text-slate-900">Mandatory Canary Verification</div>
                  <div className="text-[11px] text-slate-500">Simulate 10 mock transactions before live patch rollout</div>
                </div>
                <input
                  type="checkbox"
                  checked={canaryVerification}
                  onChange={(e) => setCanaryVerification(e.target.checked)}
                  className="w-4 h-4 accent-teal-600 rounded"
                />
              </div>

              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
                <div>
                  <div className="font-semibold text-slate-900">Real-Time Slack/Pager Webhook</div>
                  <div className="text-[11px] text-slate-500">Notify on high severity failures (e.g. INC-0042)</div>
                </div>
                <input
                  type="checkbox"
                  checked={notificationAlerts}
                  onChange={(e) => setNotificationAlerts(e.target.checked)}
                  className="w-4 h-4 accent-teal-600 rounded"
                />
              </div>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={onCloseSettings}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs rounded-lg cursor-pointer"
              >
                Save Preferences
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
