import React from 'react';
import { ChevronRight, RotateCcw, Package } from 'lucide-react';

interface QuickActionsCardProps {
  onTrackOrder: () => void;
  onCheckRefund: () => void;
}

export const QuickActionsCard: React.FC<QuickActionsCardProps> = ({
  onTrackOrder,
  onCheckRefund,
}) => {
  const actions = [
    {
      title: 'Track an Order',
      description: 'Check active delivery pipeline status',
      icon: Package,
      onClick: onTrackOrder,
    },
    {
      title: 'Check Refund Status',
      description: 'View settlement and gateway progress',
      icon: RotateCcw,
      onClick: onCheckRefund,
    },
  ];

  return (
    <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-5">
      <h3 className="text-sm font-bold text-slate-900 tracking-tight mb-3">Quick Actions</h3>
      <div className="space-y-2">
        {actions.map((act) => {
          const Icon = act.icon;
          return (
            <button
              key={act.title}
              onClick={act.onClick}
              className="w-full flex items-center justify-between p-3 rounded-xl border border-slate-100 hover:border-teal-200 hover:bg-teal-50/40 transition-all text-left group cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center shrink-0 group-hover:bg-teal-600 group-hover:text-white transition-colors">
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-semibold text-slate-900 group-hover:text-teal-900">
                    {act.title}
                  </div>
                  <div className="text-[11px] text-slate-500">{act.description}</div>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-teal-600 group-hover:translate-x-0.5 transition-all shrink-0" />
            </button>
          );
        })}
      </div>
    </div>
  );
};
