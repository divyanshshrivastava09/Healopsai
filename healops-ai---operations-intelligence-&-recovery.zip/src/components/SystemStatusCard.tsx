import React from 'react';
import { ServiceStatus } from '../types';

interface SystemStatusCardProps {
  services: ServiceStatus[];
  lastUpdated?: string;
}

export const SystemStatusCard: React.FC<SystemStatusCardProps> = ({
  services,
  lastUpdated = '12:50 PM',
}) => {
  const onlineCount = services.filter((s) => s.status === 'online').length;
  const totalCount = services.length;

  return (
    <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-5 flex flex-col justify-between h-full">
      {/* Header */}
      <div className="flex items-center justify-between pb-1 border-b border-slate-100">
        <div>
          <h3 className="text-sm font-bold text-slate-900 tracking-tight">System Status</h3>
          <p className="text-[11px] text-slate-400">Core microservices availability</p>
        </div>
      </div>

      {/* Donut and Legend row */}
      <div className="flex items-center justify-between gap-4 my-2">
        {/* Circular Donut Gauge */}
        <div className="relative w-28 h-28 flex items-center justify-center shrink-0">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            {/* Background ring */}
            <circle
              cx="50"
              cy="50"
              r="40"
              fill="transparent"
              stroke="#F1F5F9"
              strokeWidth="9"
            />
            {/* Progress ring */}
            <circle
              cx="50"
              cy="50"
              r="40"
              fill="transparent"
              stroke="#14B8A6"
              strokeWidth="9"
              strokeDasharray={2 * Math.PI * 40}
              strokeDashoffset={2 * Math.PI * 40 * (1 - onlineCount / totalCount)}
              strokeLinecap="round"
              className="transition-all duration-700 ease-out"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-2">
            <span className="text-sm font-bold text-slate-900 leading-none tabular-nums font-mono">
              {onlineCount}/{totalCount}
            </span>
            <span className="text-[10px] text-slate-400 font-medium mt-1 leading-tight">
              Online
            </span>
          </div>
        </div>

        {/* Services List with Dots */}
        <div className="flex-1 space-y-1.5 pl-2">
          {services.map((svc) => (
            <div key={svc.name} className="flex items-center gap-2 text-xs text-slate-700">
              <span
                className={`w-2 h-2 rounded-full shrink-0 ${
                  svc.status === 'online'
                    ? 'bg-teal-500'
                    : svc.status === 'degraded'
                    ? 'bg-amber-500'
                    : 'bg-red-500'
                }`}
              ></span>
              <span className="truncate text-[11px] font-medium text-slate-800">{svc.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Footer Timestamp without extra buttons */}
      <div className="pt-2.5 border-t border-slate-100 text-[11px] text-slate-400">
        <span>Last updated: {lastUpdated}</span>
      </div>
    </div>
  );
};
