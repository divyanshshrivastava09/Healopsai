/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Play, Info } from 'lucide-react';
import {
  NavigationTab,
  CustomerRequest,
  WorkflowItem,
  IncidentItem,
  RecoveryStep,
  ServiceStatus,
  WorkflowInvestigation,
} from './types';
import {
  initialCustomerRequests,
  initialWorkflowItems,
  initialSystemServices,
  initialIncidents,
  initialRecoverySteps,
  initialInvestigations,
} from './data/mockData';

// Components
import { Sidebar } from './components/Sidebar';
import { TopNav } from './components/TopNav';
import { StatsGrid } from './components/StatsGrid';
import { CustomerRequestsTable } from './components/CustomerRequestsTable';
import { WorkflowHealthCard } from './components/WorkflowHealthCard';
import { SystemStatusCard } from './components/SystemStatusCard';
import { RecentIncidentsTable } from './components/RecentIncidentsTable';
import { LiveRecoveryActivity } from './components/LiveRecoveryActivity';
import { QuickActionsCard } from './components/QuickActionsCard';
import { HelpSupportCard } from './components/HelpSupportCard';

// Modals
import { DemoScenarioModal } from './components/DemoScenarioModal';
import { IncidentDetailModal } from './components/IncidentDetailModal';
import { WorkflowDetailModal } from './components/WorkflowDetailModal';
import { CustomerRequestDetailModal } from './components/CustomerRequestDetailModal';
import { QuickActionModals } from './components/QuickActionModals';
import { WorkflowRecoveryStudioModal } from './components/WorkflowRecoveryStudioModal';
import { SubViews } from './components/views/SubViews';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('operations-overview');

  // Operational State
  const [stats, setStats] = useState({
    totalExecutions: 128,
    failedWorkflows: 12,
    verifiedRecoveries: 9,
    pendingApprovals: 2,
  });

  const [customerRequests, setCustomerRequests] = useState<CustomerRequest[]>(initialCustomerRequests);
  const [workflows, setWorkflows] = useState<WorkflowItem[]>(initialWorkflowItems);
  const [services] = useState<ServiceStatus[]>(initialSystemServices);
  const [incidents, setIncidents] = useState<IncidentItem[]>(initialIncidents);
  const [recoverySteps, setRecoverySteps] = useState<RecoveryStep[]>(initialRecoverySteps);
  const [notificationCount, setNotificationCount] = useState(3);
  const [systemHealthy, setSystemHealthy] = useState(true);

  // Selected state for recovery inspector
  const [selectedRequestForRecovery, setSelectedRequestForRecovery] = useState<CustomerRequest | null>(null);

  // Modal states
  const [demoModalOpen, setDemoModalOpen] = useState(false);
  const [selectedIncident, setSelectedIncident] = useState<IncidentItem | null>(null);
  const [selectedWorkflow, setSelectedWorkflow] = useState<WorkflowItem | null>(null);
  const [selectedRequest, setSelectedRequest] = useState<CustomerRequest | null>(null);
  const [selectedInvestigation, setSelectedInvestigation] = useState<WorkflowInvestigation | null>(null);

  // Quick Action modal states
  const [trackOrderOpen, setTrackOrderOpen] = useState(false);
  const [checkRefundOpen, setCheckRefundOpen] = useState(false);
  const [contactSupportOpen, setContactSupportOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  // Dynamic API Correction execution
  const handleApplyCorrection = (requestId: number) => {
    setCustomerRequests((prev) =>
      prev.map((req) => {
        if (req.id === requestId) {
          return {
            ...req,
            status: 'Resolved',
            apiSuitability: {
              ...req.apiSuitability,
              status: 'Corrected',
            },
          };
        }
        return req;
      })
    );

    setStats((prev) => ({
      ...prev,
      verifiedRecoveries: prev.verifiedRecoveries + 1,
      failedWorkflows: Math.max(0, prev.failedWorkflows - 1),
    }));

    // Prepend recovery timeline step
    const targetReq = customerRequests.find((r) => r.id === requestId);
    const newStep: RecoveryStep = {
      id: `rec-${Date.now()}`,
      time: '12:54',
      title: `API Schema Normalized: ${targetReq?.refId || 'Payload'}`,
      subtitle: `${targetReq?.apiSuitability.correctionStrategy || 'Adapter verified'} (0 errors)`,
      type: 'verified',
    };
    setRecoverySteps((prev) => [newStep, ...prev]);
  };

  // 4-Stage Lifecycle: Validate, Human Approval & Automated Retry Handler
  const handleApproveAndRetry = (workflowId: string) => {
    if (workflowId === 'wf-5') {
      // Invoice Processing Pipeline (Required Human Approval)
      setStats((prev) => ({
        ...prev,
        pendingApprovals: Math.max(0, prev.pendingApprovals - 1),
        failedWorkflows: Math.max(0, prev.failedWorkflows - 1),
        verifiedRecoveries: prev.verifiedRecoveries + 1,
        totalExecutions: prev.totalExecutions + 1,
      }));

      setWorkflows((prev) =>
        prev.map((wf) =>
          wf.id === 'wf-5'
            ? { ...wf, health: 'Healthy', recoveryStatus: '+ Recovered', recentFailures: 0 }
            : wf
        )
      );

      setIncidents((prev) =>
        prev.map((inc) => (inc.id === 'INC-0039' ? { ...inc, status: 'Resolved' } : inc))
      );

      const newStep: RecoveryStep = {
        id: `rec-${Date.now()}`,
        time: '12:55',
        title: 'Human Approval Verified & Retry Executed',
        subtitle: 'Invoice Pipeline failover route verified (TaxJar backup)',
        type: 'verified',
      };
      setRecoverySteps((prev) => [newStep, ...prev]);
    } else if (workflowId === 'wf-2') {
      // Order Processing Service
      setStats((prev) => ({
        ...prev,
        failedWorkflows: Math.max(0, prev.failedWorkflows - 1),
        verifiedRecoveries: prev.verifiedRecoveries + 1,
        totalExecutions: prev.totalExecutions + 1,
      }));

      setWorkflows((prev) =>
        prev.map((wf) =>
          wf.id === 'wf-2'
            ? { ...wf, health: 'Healthy', recoveryStatus: '+ Recovered', recentFailures: 0 }
            : wf
        )
      );

      setIncidents((prev) =>
        prev.map((inc) => (inc.id === 'INC-0042' ? { ...inc, status: 'Resolved' } : inc))
      );

      const newStep: RecoveryStep = {
        id: `rec-${Date.now()}`,
        time: '12:53',
        title: 'Automated Fix Validated & Retry Succeeded',
        subtitle: 'Order Service schema adapter applied (0 errors)',
        type: 'verified',
      };
      setRecoverySteps((prev) => [newStep, ...prev]);
    }
  };

  // Demo Scenario Handler
  const handleApplyDemoScenario = () => {
    setStats((prev) => ({
      ...prev,
      totalExecutions: prev.totalExecutions + 1,
      verifiedRecoveries: prev.verifiedRecoveries + 1,
      failedWorkflows: Math.max(0, prev.failedWorkflows - 1),
    }));

    // Mark INC-0042 as resolved
    setIncidents((prev) =>
      prev.map((inc) => (inc.id === 'INC-0042' ? { ...inc, status: 'Resolved' } : inc))
    );

    // Update Order Processing workflow to healthy
    setWorkflows((prev) =>
      prev.map((wf) =>
        wf.id === 'wf-2' ? { ...wf, health: 'Healthy', recoveryStatus: '+ Recovered' } : wf
      )
    );

    // Prepend a fresh recovery step
    const newStep: RecoveryStep = {
      id: `rec-${Date.now()}`,
      time: '12:52',
      title: 'Canary test validated & verified',
      subtitle: 'Order Service auto-healed (0 errors)',
      type: 'verified',
    };
    setRecoverySteps((prev) => [newStep, ...prev]);
  };

  const handleResolveIncident = (incidentId: string) => {
    setIncidents((prev) =>
      prev.map((inc) => (inc.id === incidentId ? { ...inc, status: 'Resolved' } : inc))
    );
    setStats((prev) => ({
      ...prev,
      verifiedRecoveries: prev.verifiedRecoveries + 1,
      failedWorkflows: Math.max(0, prev.failedWorkflows - 1),
    }));
  };

  return (
    <div className="min-h-screen flex bg-[#F4F7FC] text-slate-800 font-sans antialiased selection:bg-teal-100 selection:text-teal-900">
      {/* 1. Left Sidebar */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenSettings={() => setSettingsOpen(true)}
        systemHealthy={systemHealthy}
      />

      {/* 2. Main Content Canvas */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">
        {/* Top Dark Header Bar */}
        <TopNav
          onRunDemo={() => setDemoModalOpen(true)}
          systemHealthy={systemHealthy}
          notificationCount={notificationCount}
          onClearNotifications={() => setNotificationCount(0)}
        />

        {/* View Content */}
        <main className="flex-1 p-6 max-w-[1600px] w-full mx-auto space-y-5">
          {activeTab === 'operations-overview' ? (
            <>
              {/* Header with Title and "Run Demo Scenario" CTA */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
                    Operations Overview
                  </h1>
                  <p className="text-xs text-slate-500 mt-1 font-normal">
                    Monitor customer operations, investigate failures, and verify automated recovery.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      // Open recovery investigation directly
                      setSelectedInvestigation(initialInvestigations['wf-5']);
                    }}
                    className="px-3.5 py-2.5 text-xs font-semibold text-teal-800 bg-white hover:bg-teal-50 border border-teal-200 rounded-lg shadow-2xs transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <span>Inspect Pending Approval</span>
                    <span className="w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center font-bold">
                      {stats.pendingApprovals}
                    </span>
                  </button>
                  <button
                    onClick={() => setDemoModalOpen(true)}
                    className="px-4 py-2.5 text-xs font-semibold text-white bg-[#0D9488] hover:bg-[#0F766E] rounded-lg shadow-xs hover:shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer shrink-0"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Run Demo Scenario</span>
                  </button>
                </div>
              </div>

              {/* SIMULATED ENVIRONMENT Alert Banner (clean & quiet) */}
              <div className="bg-[#EEFBFB] border border-[#BDEFEF] rounded-xl px-4 py-2.5 flex items-center gap-3 text-slate-700 shadow-2xs">
                <div className="w-5 h-5 rounded-full bg-[#CCF4F4] text-[#0F766E] flex items-center justify-center shrink-0">
                  <Info className="w-3.5 h-3.5" />
                </div>
                <div className="text-xs leading-snug">
                  <span className="font-bold text-[#0F766E] tracking-wide text-[11px] uppercase mr-2">
                    SIMULATED ENVIRONMENT
                  </span>
                  <span className="text-slate-600 font-normal">
                    Demo workflows use controlled sample data and isolated test operations.
                  </span>
                </div>
              </div>

              {/* 4 Stats KPI Cards (with click-to-investigate on Failed & Pending Approvals) */}
              <StatsGrid
                stats={stats}
                onSelectFailedWorkflows={() => setSelectedInvestigation(initialInvestigations['wf-2'])}
                onSelectPendingApprovals={() => setSelectedInvestigation(initialInvestigations['wf-5'])}
              />

              {/* Main 2-Column Operational Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
                {/* Left Column (~68% width on desktop) */}
                <div className="lg:col-span-8 space-y-5">
                  {/* Clean Recent Customer Requests Table */}
                  <CustomerRequestsTable
                    requests={customerRequests}
                    onSelectRequest={(req) => setSelectedRequest(req)}
                  />

                  {/* Middle Sub-Grid: Workflow Health & System Status */}
                  <div className="grid grid-cols-1 xl:grid-cols-12 gap-5 items-stretch">
                    <div className="xl:col-span-7">
                      <WorkflowHealthCard
                        workflows={workflows}
                        onSelectWorkflow={(wf) => {
                          if (initialInvestigations[wf.id]) {
                            setSelectedInvestigation(initialInvestigations[wf.id]);
                          } else {
                            setSelectedWorkflow(wf);
                          }
                        }}
                      />
                    </div>
                    <div className="xl:col-span-5">
                      <SystemStatusCard
                        services={services}
                        lastUpdated="12:50 PM"
                      />
                    </div>
                  </div>

                  {/* Clean Recent Incidents Table */}
                  <RecentIncidentsTable
                    incidents={incidents}
                    onSelectIncident={(inc) => {
                      if (inc.id === 'INC-0042' && initialInvestigations['wf-2']) {
                        setSelectedInvestigation(initialInvestigations['wf-2']);
                      } else if (inc.id === 'INC-0039' && initialInvestigations['wf-5']) {
                        setSelectedInvestigation(initialInvestigations['wf-5']);
                      } else {
                        setSelectedIncident(inc);
                      }
                    }}
                  />
                </div>

                {/* Right Column (~32% width on desktop) */}
                <div className="lg:col-span-4 space-y-5">
                  {/* Live Recovery Activity */}
                  <LiveRecoveryActivity
                    steps={recoverySteps}
                    onStepClick={(step) => {
                      if (initialInvestigations['wf-2']) {
                        setSelectedInvestigation(initialInvestigations['wf-2']);
                      }
                    }}
                  />

                  {/* Quick Actions */}
                  <QuickActionsCard
                    onTrackOrder={() => setTrackOrderOpen(true)}
                    onCheckRefund={() => setCheckRefundOpen(true)}
                  />

                  {/* Need More Help? */}
                  <HelpSupportCard onContactSupport={() => setContactSupportOpen(true)} />
                </div>
              </div>
            </>
          ) : (
            <SubViews
              tab={activeTab}
              onBackToOverview={() => setActiveTab('operations-overview')}
              customerRequests={customerRequests}
              workflows={workflows}
              incidents={incidents}
              services={services}
              onSelectIncident={(inc) => {
                if (inc.id === 'INC-0042' && initialInvestigations['wf-2']) {
                  setSelectedInvestigation(initialInvestigations['wf-2']);
                } else if (inc.id === 'INC-0039' && initialInvestigations['wf-5']) {
                  setSelectedInvestigation(initialInvestigations['wf-5']);
                } else {
                  setSelectedIncident(inc);
                }
              }}
              selectedRequestForRecovery={selectedRequestForRecovery}
              onSelectRequestForRecovery={setSelectedRequestForRecovery}
              onApplyCorrection={handleApplyCorrection}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}
        </main>
      </div>

      {/* 4-Stage Workflow Recovery Studio Modal (Monitor, Analyze, Recommend, Validate & Retry with Human Approval) */}
      <WorkflowRecoveryStudioModal
        investigation={selectedInvestigation}
        onClose={() => setSelectedInvestigation(null)}
        onApproveAndRetry={handleApproveAndRetry}
      />

      {/* Interactive Modals */}
      <DemoScenarioModal
        isOpen={demoModalOpen}
        onClose={() => setDemoModalOpen(false)}
        onApplyScenario={handleApplyDemoScenario}
      />

      <IncidentDetailModal
        incident={selectedIncident}
        onClose={() => setSelectedIncident(null)}
        onResolve={handleResolveIncident}
      />

      <WorkflowDetailModal
        workflow={selectedWorkflow}
        onClose={() => setSelectedWorkflow(null)}
      />

      <CustomerRequestDetailModal
        request={selectedRequest}
        onClose={() => setSelectedRequest(null)}
        onNavigateToRecovery={(req) => {
          setSelectedRequestForRecovery(req);
          setActiveTab('recovery-center');
        }}
        onNavigateToHealth={(req) => {
          setSelectedRequestForRecovery(req);
          setActiveTab('system-health');
        }}
      />

      <QuickActionModals
        trackOrderOpen={trackOrderOpen}
        onCloseTrackOrder={() => setTrackOrderOpen(false)}
        checkRefundOpen={checkRefundOpen}
        onCloseCheckRefund={() => setCheckRefundOpen(false)}
        contactSupportOpen={contactSupportOpen}
        onCloseContactSupport={() => setContactSupportOpen(false)}
        settingsOpen={settingsOpen}
        onCloseSettings={() => setSettingsOpen(false)}
      />
    </div>
  );
}
