export type NavigationTab =
  | 'operations-overview'
  | 'customer-support'
  | 'order-tracking'
  | 'refund-support'
  | 'workflow-monitor'
  | 'incident-intelligence'
  | 'recovery-center'
  | 'system-health'
  | 'recovery-history'
  | 'system-architecture'
  | 'settings';

export interface ApiDataSuitability {
  status: 'Suitable' | 'Unsuitable' | 'Corrected';
  anomalyType: string;
  detectedIssue: string;
  inboundPayload: Record<string, any>;
  correctedPayload: Record<string, any>;
  correctionStrategy: string;
  impactMetrics: {
    latencyChange: string;
    errorRateChange: string;
    throughputChange: string;
    businessImpact: string;
    uptimePreserved: string;
  };
}

export interface CustomerRequest {
  id: number;
  message: string;
  category: string;
  refId: string;
  status: 'Resolved' | 'In Progress' | 'Open' | 'Pending';
  resolution: string;
  timestamp?: string;
  customerName?: string;
  apiSuitability: ApiDataSuitability;
}

export interface WorkflowItem {
  id: string;
  name: string;
  health: 'Healthy' | 'Degraded' | 'Failed';
  lastExecution: string;
  recentFailures: number;
  recoveryStatus: string;
  uptime: string;
  avgLatency: string;
}

export interface IncidentItem {
  id: string;
  workflow: string;
  failureType: string;
  severity: 'High' | 'Medium' | 'Low';
  detectedAt: string;
  status: 'Diagnosed' | 'In Progress' | 'Resolved' | 'Escalated';
  rootCause?: string;
  suggestedPatch?: string;
  affectedCustomers?: number;
  apiDataSuitability?: ApiDataSuitability;
}

export interface RecoveryStep {
  id: string;
  time: string;
  title: string;
  subtitle: string;
  type: 'alert' | 'diagnostic' | 'plan' | 'validation' | 'retry' | 'verified' | 'closed';
}

export interface ServiceStatus {
  name: string;
  status: 'online' | 'degraded' | 'offline';
  latency: string;
}

export interface WorkflowInvestigation {
  workflowId: string;
  workflowName: string;
  incidentId: string;
  detectedAt: string;
  stage: 'monitoring' | 'analyzing' | 'recommending' | 'validating' | 'awaiting_approval' | 'retrying' | 'completed';
  errorDetails: {
    code: string;
    message: string;
    component: string;
    impact: string;
  };
  logAnalysis: {
    stackTrace: string[];
    likelyCause: string;
    confidence: number;
    evidence: string;
  };
  correctiveAction: {
    title: string;
    description: string;
    patchDiff: {
      before: string;
      after: string;
    };
    riskLevel: 'Low' | 'Medium' | 'High';
    requiresHumanApproval: boolean;
  };
  validationResults: {
    checks: { name: string; passed: boolean; latency: string }[];
    canaryOutcome: string;
    verifiedAssertions: number;
  };
  retryState: {
    status: 'pending' | 'executing' | 'succeeded' | 'failed';
    outputData: Record<string, any>;
    timeElapsed: string;
  };
}
