import { CustomerRequest, WorkflowItem, IncidentItem, RecoveryStep, ServiceStatus } from '../types';

export const initialCustomerRequests: CustomerRequest[] = [
  {
    id: 1,
    message: 'Where is my order?',
    category: 'Order Tracking',
    refId: 'ORD-10023',
    status: 'Resolved',
    resolution: 'Order found',
    timestamp: '12:48 PM',
    customerName: 'Alex Mercer',
    apiSuitability: {
      status: 'Corrected',
      anomalyType: 'Key Naming Mismatch',
      detectedIssue: 'Inbound order payload used legacy key "customer_obj.name" missing mandatory root "customer_name" required by Order Processing v2 API',
      inboundPayload: {
        order_id: 'ORD-10023',
        customer_obj: { name: 'Alex Mercer' },
        status: 'dispatch_pending'
      },
      correctedPayload: {
        order_id: 'ORD-10023',
        customer_name: 'Alex Mercer',
        customer_obj: { name: 'Alex Mercer' },
        status: 'dispatch_pending',
        _schema_adapted: true
      },
      correctionStrategy: 'Bidirectional JSON Schema Adapter & Key Fallback',
      impactMetrics: {
        latencyChange: '-240ms (from 310ms timeout to 70ms)',
        errorRateChange: '-100% (eliminated 400 Bad Request)',
        throughputChange: '+45 req/s sustained',
        businessImpact: 'Order ORD-10023 processed without warehouse hold',
        uptimePreserved: '99.99%'
      }
    }
  },
  {
    id: 2,
    message: 'I need a refund',
    category: 'Refund Inquiry',
    refId: 'REF-5521',
    status: 'In Progress',
    resolution: 'Processing',
    timestamp: '12:45 PM',
    customerName: 'Sarah Jenkins',
    apiSuitability: {
      status: 'Unsuitable',
      anomalyType: 'Type Coercion & Currency Float Error',
      detectedIssue: 'Webhook sent refund amount as unparsed string "$142.50 USD" instead of float 142.50 with separate currency ISO code',
      inboundPayload: {
        refund_id: 'REF-5521',
        amount: '$142.50 USD',
        customer_id: 'usr_9921',
        gateway: 'stripe_v2'
      },
      correctedPayload: {
        refund_id: 'REF-5521',
        amount: 142.50,
        currency: 'USD',
        customer_id: 'usr_9921',
        gateway: 'stripe_v2',
        _sanitized: true
      },
      correctionStrategy: 'Regex Currency Tokenizer & Float Cast Parser',
      impactMetrics: {
        latencyChange: '-850ms (avoided retry queue delay)',
        errorRateChange: 'Prevented payment gateway rejection (422 Unprocessable Entity)',
        throughputChange: '+18 refunds/min',
        businessImpact: 'Customer refund unblocked instantly without finance escalation',
        uptimePreserved: '99.95%'
      }
    }
  },
  {
    id: 3,
    message: 'My order is delayed',
    category: 'Delivery Delay',
    refId: 'ORD-10087',
    status: 'Open',
    resolution: 'Investigating',
    timestamp: '12:40 PM',
    customerName: 'Marcus Vance',
    apiSuitability: {
      status: 'Unsuitable',
      anomalyType: 'Timestamp ISO-8601 Malformation',
      detectedIssue: 'Carrier tracking webhook transmitted Unix millisecond timestamp string instead of ISO-8601 UTC string',
      inboundPayload: {
        tracking_id: 'ORD-10087',
        carrier: 'Express Carrier',
        dispatch_time: '1729871234000'
      },
      correctedPayload: {
        tracking_id: 'ORD-10087',
        carrier: 'Express Carrier',
        dispatch_time: '2026-10-27T22:15:00.000Z',
        _normalized: true
      },
      correctionStrategy: 'Epoch Timestamp Transformer & Timezone Normalizer',
      impactMetrics: {
        latencyChange: '-120ms',
        errorRateChange: 'Zero delivery timeline calculation exceptions',
        throughputChange: '+30 tracking syncs/s',
        businessImpact: 'Package tracking status updated in customer app accurately',
        uptimePreserved: '99.98%'
      }
    }
  },
  {
    id: 4,
    message: 'Payment not processed',
    category: 'Payment Issue',
    refId: 'ORD-10056',
    status: 'Resolved',
    resolution: 'Issue fixed',
    timestamp: '12:35 PM',
    customerName: 'Elena Rostova',
    apiSuitability: {
      status: 'Corrected',
      anomalyType: 'Missing Required Metadata Header',
      detectedIssue: 'Payment event missing X-Idempotency-Key header; upstream generated duplicate payload',
      inboundPayload: {
        order_id: 'ORD-10056',
        payment_token: 'tok_9981',
        duplicate_attempt: 2
      },
      correctedPayload: {
        order_id: 'ORD-10056',
        payment_token: 'tok_9981',
        idempotency_key: 'idem_ord_10056_h1',
        _deduplicated: true
      },
      correctionStrategy: 'Deterministic Hash Idempotency Synthesizer',
      impactMetrics: {
        latencyChange: '-45ms',
        errorRateChange: 'Prevented double-charge risk on customer credit card',
        throughputChange: '100% duplicate rejection',
        businessImpact: 'Preserved merchant trust; prevented dispute chargeback fee',
        uptimePreserved: '99.99%'
      }
    }
  },
  {
    id: 5,
    message: 'General support',
    category: 'General Support',
    refId: '—',
    status: 'Resolved',
    resolution: 'Information provided',
    timestamp: '12:28 PM',
    customerName: 'David Kim',
    apiSuitability: {
      status: 'Suitable',
      anomalyType: 'None (Compliant Schema)',
      detectedIssue: 'Payload conforms to v2 API schema contract and invariants.',
      inboundPayload: {
        session_id: 'sess_441',
        channel: 'in_app_chat',
        intent: 'general_inquiry'
      },
      correctedPayload: {
        session_id: 'sess_441',
        channel: 'in_app_chat',
        intent: 'general_inquiry'
      },
      correctionStrategy: 'Direct Line Pass-Through',
      impactMetrics: {
        latencyChange: 'Nominal (18ms)',
        errorRateChange: '0.00%',
        throughputChange: 'Full line rate',
        businessImpact: 'Standard operation',
        uptimePreserved: '100%'
      }
    }
  }
];

export const initialWorkflowItems: WorkflowItem[] = [
  {
    id: 'wf-1',
    name: 'Customer Support API',
    health: 'Healthy',
    lastExecution: '2 min ago',
    recentFailures: 0,
    recoveryStatus: '—',
    uptime: '99.98%',
    avgLatency: '142ms'
  },
  {
    id: 'wf-2',
    name: 'Order Processing Service',
    health: 'Degraded',
    lastExecution: '5 min ago',
    recentFailures: 2,
    recoveryStatus: '+ In Progress',
    uptime: '98.42%',
    avgLatency: '418ms'
  },
  {
    id: 'wf-3',
    name: 'Refund Status Service',
    health: 'Healthy',
    lastExecution: '12 min ago',
    recentFailures: 0,
    recoveryStatus: '—',
    uptime: '99.95%',
    avgLatency: '185ms'
  },
  {
    id: 'wf-4',
    name: 'Customer Data Sync',
    health: 'Healthy',
    lastExecution: '18 min ago',
    recentFailures: 1,
    recoveryStatus: '+ Recovered',
    uptime: '99.80%',
    avgLatency: '210ms'
  },
  {
    id: 'wf-5',
    name: 'Invoice Processing Pipeline',
    health: 'Failed',
    lastExecution: '32 min ago',
    recentFailures: 3,
    recoveryStatus: 'Needs Attention',
    uptime: '95.12%',
    avgLatency: '890ms'
  }
];

export const initialSystemServices: ServiceStatus[] = [
  { name: 'Customer Support API', status: 'online', latency: '45ms' },
  { name: 'Order Service', status: 'online', latency: '68ms' },
  { name: 'Refund Service', status: 'online', latency: '52ms' },
  { name: 'AI Diagnostic Service', status: 'online', latency: '110ms' },
  { name: 'Recovery Engine', status: 'online', latency: '95ms' },
  { name: 'Database', status: 'online', latency: '18ms' }
];

export const initialIncidents: IncidentItem[] = [
  {
    id: 'INC-0042',
    workflow: 'Order Processing',
    failureType: 'API Timeout',
    severity: 'High',
    detectedAt: '12:42 PM',
    status: 'Diagnosed',
    rootCause: 'Upstream payment gateway timeout during burst checkout traffic. Circuit breaker tripped.',
    suggestedPatch: 'Automated fallback route to standby gateway with exponential retry jitter.',
    affectedCustomers: 18,
    apiDataSuitability: {
      status: 'Unsuitable',
      anomalyType: 'Key Naming Mismatch',
      detectedIssue: 'Missing required property "customer_name" in POST /v2/orders/ingest',
      inboundPayload: {
        order_id: 'ORD-10023',
        customer: { full_name: 'Alex Mercer' },
        status: 'pending_dispatch'
      },
      correctedPayload: {
        order_id: 'ORD-10023',
        customer_name: 'Alex Mercer',
        customer: { full_name: 'Alex Mercer' },
        status: 'pending_dispatch'
      },
      correctionStrategy: 'Dynamic AST Schema Transformer Adapter',
      impactMetrics: {
        latencyChange: 'Reduced from 3,200ms (timeout) to 42ms',
        errorRateChange: 'Order failure rate dropped from 14.8% to 0.00%',
        throughputChange: 'Throughput restored to 1,200 orders/minute',
        businessImpact: 'Zero lost sales; 18 customer checkouts recovered autonomously',
        uptimePreserved: 'Preserved 99.98% Service Level Objective'
      }
    }
  },
  {
    id: 'INC-0041',
    workflow: 'Refund Service',
    failureType: 'Schema Mismatch',
    severity: 'Medium',
    detectedAt: '11:36 AM',
    status: 'In Progress',
    rootCause: 'Payload field mapping missing "customer_name" vs "customer" in v2 refund schema webhook.',
    suggestedPatch: 'Apply bidirectional field alias adapter in ingest transformation pipeline.',
    affectedCustomers: 4
  },
  {
    id: 'INC-0040',
    workflow: 'Support API',
    failureType: 'Rate Limit Exceeded',
    severity: 'Low',
    detectedAt: '10:21 AM',
    status: 'Resolved',
    rootCause: 'CRM sync job exceeded 120 req/min threshold due to backlog processing.',
    suggestedPatch: 'Dynamic token bucket rate-smoothing queue applied and verified.',
    affectedCustomers: 0
  },
  {
    id: 'INC-0039',
    workflow: 'Invoice Pipeline',
    failureType: 'Invalid Response',
    severity: 'High',
    detectedAt: '09:12 AM',
    status: 'Escalated',
    rootCause: 'Third-party accounting provider returned 502 Bad Gateway with malformed XML wrapper.',
    suggestedPatch: 'Manual review required by Finance Ops team. Webhook retry suspended.',
    affectedCustomers: 7
  },
  {
    id: 'INC-0038',
    workflow: 'Data Sync',
    failureType: 'Service Unavailable',
    severity: 'Medium',
    detectedAt: '08:45 AM',
    status: 'Resolved',
    rootCause: 'Redis replica failover sync delay caused read stale lock.',
    suggestedPatch: 'Auto-switched client connection pool to primary node; self-healed in 18s.',
    affectedCustomers: 2
  }
];

export const initialRecoverySteps: RecoveryStep[] = [
  {
    id: 'rec-1',
    time: '12:48',
    title: 'Schema mismatch detected',
    subtitle: 'Order Service · INC-0042',
    type: 'alert'
  },
  {
    id: 'rec-2',
    time: '12:46',
    title: 'Root cause identified',
    subtitle: 'Payload field mapping issue',
    type: 'diagnostic'
  },
  {
    id: 'rec-3',
    time: '12:44',
    title: 'Recovery plan generated',
    subtitle: 'Map customer → customer_name',
    type: 'plan'
  },
  {
    id: 'rec-4',
    time: '12:46',
    title: 'Validation completed',
    subtitle: 'Schema and business rules passed',
    type: 'validation'
  },
  {
    id: 'rec-5',
    time: '12:48',
    title: 'Retry executed',
    subtitle: 'Order lookup retried successfully',
    type: 'retry'
  },
  {
    id: 'rec-6',
    time: '12:50',
    title: 'Output verified',
    subtitle: 'Order data retrieved correctly',
    type: 'verified'
  },
  {
    id: 'rec-7',
    time: '12:50',
    title: 'Incident closed',
    subtitle: 'Recovery verified',
    type: 'closed'
  }
];

export const initialInvestigations: Record<string, import('../types').WorkflowInvestigation> = {
  'wf-2': {
    workflowId: 'wf-2',
    workflowName: 'Order Processing Service',
    incidentId: 'INC-0042',
    detectedAt: '12:42 PM',
    stage: 'validating',
    errorDetails: {
      code: 'ERR_SCHEMA_MISMATCH_400',
      message: "Uncaught ValidationError: property 'customer_name' missing in order ingestion payload",
      component: 'Order Ingest Webhook (v2.4.1)',
      impact: '18 customer orders held at gateway without dispatch'
    },
    logAnalysis: {
      stackTrace: [
        'ValidationError: property "customer_name" is required by schema #/definitions/OrderIngest',
        '    at SchemaValidator.validate (/opt/node/services/order/validator.ts:84:15)',
        '    at OrderIngestController.handlePost (/opt/node/services/order/controller.ts:42:10)',
        '    at dispatchRoute (/opt/node/framework/router.ts:112:8)'
      ],
      likelyCause: 'Upstream checkout client transmitted legacy format { customer: { full_name } } instead of root "customer_name".',
      confidence: 99.4,
      evidence: 'AST payload analysis shows field "customer.full_name" populated with identical string data.'
    },
    correctiveAction: {
      title: 'Synthesize Bidirectional AST Alias Adapter',
      description: 'Dynamically normalize incoming JSON payload by aliasing "customer.full_name" to root "customer_name" before schema assertion.',
      patchDiff: {
        before: 'const { customer_name, order_id } = req.body;\nif (!customer_name) throw new ValidationError("Missing customer_name");',
        after: '// HealOps AI Autonomous Schema Adapter\nconst customer_name = req.body.customer_name || req.body.customer?.full_name;\nconst adaptedBody = { ...req.body, customer_name };'
      },
      riskLevel: 'Low',
      requiresHumanApproval: false
    },
    validationResults: {
      checks: [
        { name: 'Schema Contract Invariants', passed: true, latency: '0.8ms' },
        { name: 'Backward Compatibility Check', passed: true, latency: '1.1ms' },
        { name: 'Database Foreign Key Integrity', passed: true, latency: '2.4ms' },
        { name: 'Memory Allocation & Idempotency', passed: true, latency: '0.4ms' }
      ],
      canaryOutcome: '14/14 synthetic test payloads processed without exceptions',
      verifiedAssertions: 14
    },
    retryState: {
      status: 'pending',
      outputData: {
        order_id: 'ORD-10023',
        status: 'dispatched',
        fulfillment_node: 'node-west-01',
        tracking_ref: 'TRK-99201'
      },
      timeElapsed: '42ms'
    }
  },
  'wf-5': {
    workflowId: 'wf-5',
    workflowName: 'Invoice Processing Pipeline',
    incidentId: 'INC-0039',
    detectedAt: '09:12 AM',
    stage: 'awaiting_approval',
    errorDetails: {
      code: 'ERR_UPSTREAM_GATEWAY_502',
      message: 'Third-party accounting provider returned 502 Bad Gateway with malformed XML wrapper',
      component: 'Tax & Invoice Settlement Pipeline',
      impact: '7 enterprise billing batches delayed (> $48,200 pending settlement)'
    },
    logAnalysis: {
      stackTrace: [
        'AxiosError: Request failed with status code 502',
        '    at settleInvoiceBatch (/opt/node/services/invoice/gateway.ts:145:12)',
        '    at async PipelineWorker.runTask (/opt/node/services/invoice/worker.ts:77:9)',
        '    at TCPConnectWrap.afterConnect [as oncomplete] (net.js:1144:16)'
      ],
      likelyCause: 'Primary accounting partner tax clearing gateway experiencing sustained 100% packet drop due to unannounced regional outage.',
      confidence: 98.2,
      evidence: '5 consecutive 502 errors and TCP RST packets received from primary upstream endpoint.'
    },
    correctiveAction: {
      title: 'Circuit-Breaker Failover to Secondary Certified Clearinghouse',
      description: 'Temporarily reroute invoice ledger settlement to verified secondary tax provider (TaxJar Backup Engine) with asynchronous audit log synchronization.',
      patchDiff: {
        before: 'const gateway = ClientRegistry.getPrimaryTaxGateway();\nawait gateway.settleBatch(invoices);',
        after: '// HealOps AI Automated Failover Route\nconst gateway = CircuitBreaker.isTripped("primary_tax")\n  ? ClientRegistry.getSecondaryTaxGateway()\n  : ClientRegistry.getPrimaryTaxGateway();\nawait gateway.settleBatch(invoices, { auditSync: true });'
      },
      riskLevel: 'High',
      requiresHumanApproval: true
    },
    validationResults: {
      checks: [
        { name: 'Secondary Gateway Availability Ping', passed: true, latency: '12ms' },
        { name: 'Tax Rate Calculation Parity', passed: true, latency: '4.8ms' },
        { name: 'Ledger Audit Invariant Assertion', passed: true, latency: '6.2ms' },
        { name: 'Double-Entry Reconciliation Hash', passed: true, latency: '1.9ms' }
      ],
      canaryOutcome: 'Canary dry-run simulation on 5 test batches succeeded with identical ledger checksums',
      verifiedAssertions: 12
    },
    retryState: {
      status: 'pending',
      outputData: {
        batch_id: 'BATCH-2026-10-27-09',
        settled_count: 7,
        total_amount: '$48,200.00 USD',
        clearing_provider: 'Secondary Backup Gateway (TaxJar)'
      },
      timeElapsed: '180ms'
    }
  }
};

